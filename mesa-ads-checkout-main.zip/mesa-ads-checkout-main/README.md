# mesa-ads-checkout

**Protótipo** do auto-checkout do mesa.ads — fluxo que o anunciante usa para montar uma campanha (porta-copos, telas VIP, janelas digitais) em minutos.

> ⚠️ Este repo é uma referência visual e funcional. A implementação final vive dentro do ERP (`app.mesaads.com.br`), reusando modelos de dados, preços e auth existentes. Veja o prompt de migração em `.claude/plans/snazzy-doodling-wind.md` (Parte 3 · Prompt 2) da workspace que originou este código.

## Stack

- Vite 5 + React 18 + TypeScript
- Tailwind v3 (design tokens via CSS vars, tema light/dark)
- Framer Motion (transições entre steps) + @react-three/fiber (hero 3D + mockup 3D da arte)
- Zustand (store do checkout: produto, locais, volume, semanas, intensidade, add-ons, arte, cliente, pagamento)
- Fontes: Bricolage Grotesque Variable + Instrument Serif + JetBrains Mono

## Como rodar

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # build produção
npm run typecheck  # verificar tipos
```

## Fluxo em 8 etapas

1. **Hero / Produto** — escolhe porta-copos, telas VIP, janelas digitais ou ativação
2. **Locais** — multi-select (rede, para porta-copos) ou auto-select (Sala VIP MAO)
3. **Volume / Quantidade** — volume auto (capacidade × intensidade) ou stepper de unidades
4. **Duração** — slider de semanas em múltiplos de 4 (4 → 52)
5. **Add-ons** — (só para porta-copos) telas VIP, janelas, live marketing
6. **Arte** — upload (com mockup 3D live) ou briefing para o time criar
7. **Checkout** — dados do cliente + método de pagamento (Pix -5% / Boleto parcelado / Cartão 3×)
8. **Sucesso** — animação + ID do pedido

## Dados

Matrizes oficiais de preços e inventário ficam em `src/data/`:

- `pricing.ts` — matriz 20×13 de porta-copos + preços de Telas VIP (9k base) + Janelas (12k base) com descontos de prazo
- `venues.ts` — 11 parceiros com capacidade, alcance, classes
- `products.ts` — definição dos produtos e add-ons

## Limites atuais (é protótipo)

- Sem backend real — pedido vive em memória (Zustand)
- Pagamento é mock visual (não integra Stripe/Pagar.me)
- Upload de arte via ObjectURL (não persiste)
- Matriz de preços transcrita das tabelas oficiais — validar com o comercial antes de produção

## Próximos passos

A versão de produção deve ser construída dentro do ERP `app.mesaads.com.br`:

- Reutilizar `calcUnitPriceAdv()` e `BV_PADRAO_AGENCIA` de `client/src/lib/campaign-builder-utils.ts`
- Reutilizar `calcImpressions()` de `client/src/hooks/useBudgetCalculator.ts`
- Criar rota `/anunciante/campanha` com gatekeeper Clerk (role `anunciante`)
- Submeter via tRPC criando `quotation` + `quotationItems`
- Tailwind 4 + shadcn/ui + Wouter (não React Router)

## Contato WhatsApp

Botão flutuante em todas as etapas (exceto sucesso) → `wa.me/5592981596354`.
