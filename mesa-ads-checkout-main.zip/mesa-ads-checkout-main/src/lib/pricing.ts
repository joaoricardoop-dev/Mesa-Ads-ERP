import type { PaymentMethod, ProductId } from '../types'
import { COMMERCIAL_TERMS } from '../data/faq'
import { lookupTotal, lookupVipTotal } from '../data/pricing'

export interface PriceBreakdown {
  base: number // total antes do desconto de pagamento
  paymentDiscount: number // Pix 5%
  total: number
  installments: number
  installmentValue: number
  method: PaymentMethod
  underConsultation?: boolean // true para 'ativacao'
}

export interface BreakdownInput {
  product: ProductId | null
  volume: number // coasters/ciclo (só usado se product='coaster')
  weeks: number
  quantity: number // unidades VIP
  addOnsMonthly: number // R$/mês somados (só coaster faz sentido)
  method: PaymentMethod
}

export function breakdownFor(input: BreakdownInput): PriceBreakdown {
  const { product, volume, weeks, quantity, addOnsMonthly, method } = input
  const cycles = cyclesFromWeeks(weeks)
  const months = cycles

  let base = 0
  let underConsultation = false

  if (product === 'coaster') {
    base = lookupTotal(volume, weeks) + addOnsMonthly * months
  } else if (product === 'vip-telas' || product === 'vip-janela') {
    base = lookupVipTotal(product, weeks, quantity)
  } else if (product === 'ativacao') {
    base = 0
    underConsultation = true
  }

  let paymentDiscount = 0
  if (method === 'pix') {
    paymentDiscount = base * (COMMERCIAL_TERMS.pixDiscountPct / 100)
  }

  const total = base - paymentDiscount

  let installments = 1
  if (method === 'boleto') installments = cycles
  if (method === 'cartao') installments = Math.min(COMMERCIAL_TERMS.maxCreditInstallments, 3)

  return {
    base,
    paymentDiscount,
    total,
    installments,
    installmentValue: total / installments,
    method,
    underConsultation,
  }
}

export function cyclesFromWeeks(weeks: number) {
  return Math.max(1, Math.round(weeks / 4))
}
