import { create } from 'zustand'
import type {
  ArtState,
  CheckoutStep,
  CustomerInfo,
  OrderSnapshot,
  PaymentMethod,
  ProductId,
} from '../types'
import { ADD_ONS } from '../data/products'
import { sumReach, sumCapacity, venueById } from '../data/venues'
import { breakdownFor, cyclesFromWeeks } from '../lib/pricing'
import { snapTo, VOLUME_STEPS } from '../data/pricing'
import { nanoid } from 'nanoid'

const STEP_ORDER: CheckoutStep[] = [
  'hero',
  'venues',
  'volume',
  'duration',
  'upsell',
  'creative',
  'checkout',
  'success',
]

// Venue fixo da Sala VIP MAO para produtos VIP (referência exibida)
export const VIP_VENUE_ID = 'harmony-lounge'

interface CheckoutState {
  step: CheckoutStep
  product: ProductId | null
  venueIds: string[]
  // coaster: volume/ciclo derivado de capacidade × intensity (persistido p/ overrides)
  volume: number
  intensity: number // 0.25 - 1.0
  // VIP: unidades (telas ou janelas)
  quantity: number
  weeks: number
  addOnIds: string[]
  art: ArtState
  customer: CustomerInfo
  payment: PaymentMethod | null
  order: OrderSnapshot | null

  // derived-data getters
  reach: () => number
  cycles: () => number
  addOnsMonthly: () => number
  suggestedVolume: () => number // capacidade × intensity, snap em VOLUME_STEPS

  // actions
  goTo: (s: CheckoutStep) => void
  next: () => void
  back: () => void
  setProduct: (p: ProductId | null) => void
  toggleVenue: (id: string) => void
  setVenues: (ids: string[]) => void
  setVolume: (n: number) => void
  setIntensity: (f: number) => void
  syncVolumeFromVenues: () => void
  setQuantity: (n: number) => void
  setWeeks: (w: number) => void
  toggleAddOn: (id: string) => void
  setArtChoice: (c: 'own' | 'agency') => void
  setArtFile: (url: string | null, name: string | null) => void
  setBriefing: (t: string) => void
  setCustomer: (patch: Partial<CustomerInfo>) => void
  setPayment: (m: PaymentMethod) => void
  placeOrder: () => void
  reset: () => void
}

const INITIAL_CUSTOMER: CustomerInfo = {
  name: '',
  email: '',
  doc: '',
  phone: '',
  company: '',
}

const INITIAL_ART: ArtState = {
  choice: null,
  fileUrl: null,
  fileName: null,
  briefing: '',
}

/** Computa volume/ciclo sugerido: capacidade total × intensidade, snap em VOLUME_STEPS. */
function computeSuggestedVolume(venueIds: string[], intensity: number): number {
  const capacity = venueIds.reduce(
    (sum, id) => sum + (venueById(id)?.capCoasters ?? 0),
    0,
  )
  if (capacity === 0) return VOLUME_STEPS[0]
  const raw = capacity * intensity
  const clamped = Math.min(
    VOLUME_STEPS[VOLUME_STEPS.length - 1],
    Math.max(VOLUME_STEPS[0], raw),
  )
  return snapTo(clamped, VOLUME_STEPS)
}

export const useCheckoutStore = create<CheckoutState>((set, get) => ({
  step: 'hero',
  product: null,
  venueIds: [],
  volume: 5000,
  intensity: 0.7,
  quantity: 1,
  weeks: 12,
  addOnIds: [],
  art: INITIAL_ART,
  customer: INITIAL_CUSTOMER,
  payment: null,
  order: null,

  reach: () => sumReach(get().venueIds),
  cycles: () => cyclesFromWeeks(get().weeks),
  addOnsMonthly: () =>
    get().addOnIds.reduce((sum, id) => {
      const ao = ADD_ONS.find((a) => a.id === id)
      return sum + (ao?.monthly ?? 0)
    }, 0),
  suggestedVolume: () => computeSuggestedVolume(get().venueIds, get().intensity),

  goTo: (s) => set({ step: s }),
  next: () => {
    const { step, product } = get()
    const order = stepsForProduct(product)
    const i = order.indexOf(step)
    if (i >= 0 && i < order.length - 1) set({ step: order[i + 1] })
  },
  back: () => {
    const { step, product } = get()
    const order = stepsForProduct(product)
    const i = order.indexOf(step)
    if (i > 0) set({ step: order[i - 1] })
  },

  setProduct: (p) => {
    // Para produtos VIP, pré-selecionar o Harmony Lounge como venue
    const patch: Partial<CheckoutState> = { product: p }
    if (p === 'vip-telas' || p === 'vip-janela' || p === 'ativacao') {
      patch.venueIds = [VIP_VENUE_ID]
      patch.quantity = 1
    } else if (p === 'coaster') {
      // limpar se vier de VIP
      patch.venueIds = []
      patch.quantity = 1
    }
    set(patch)
  },
  toggleVenue: (id) => {
    set((s) => {
      const next = s.venueIds.includes(id)
        ? s.venueIds.filter((v) => v !== id)
        : [...s.venueIds, id]
      // Resync volume quando muda venues (só coaster)
      const newVolume =
        s.product === 'coaster' ? computeSuggestedVolume(next, s.intensity) : s.volume
      return { venueIds: next, volume: newVolume }
    })
  },
  setVenues: (ids) =>
    set((s) => ({
      venueIds: ids,
      volume:
        s.product === 'coaster' ? computeSuggestedVolume(ids, s.intensity) : s.volume,
    })),
  setVolume: (n) => set({ volume: snapTo(n, VOLUME_STEPS) }),
  setIntensity: (f) =>
    set((s) => {
      const intensity = Math.max(0.25, Math.min(1, f))
      const volume =
        s.product === 'coaster'
          ? computeSuggestedVolume(s.venueIds, intensity)
          : s.volume
      return { intensity, volume }
    }),
  syncVolumeFromVenues: () =>
    set((s) => ({ volume: computeSuggestedVolume(s.venueIds, s.intensity) })),
  setQuantity: (n) => set({ quantity: Math.max(1, Math.floor(n)) }),
  setWeeks: (w) => set({ weeks: w }),
  toggleAddOn: (id) =>
    set((s) => ({
      addOnIds: s.addOnIds.includes(id)
        ? s.addOnIds.filter((a) => a !== id)
        : [...s.addOnIds, id],
    })),
  setArtChoice: (c) => set((s) => ({ art: { ...s.art, choice: c } })),
  setArtFile: (url, name) => set((s) => ({ art: { ...s.art, fileUrl: url, fileName: name } })),
  setBriefing: (t) => set((s) => ({ art: { ...s.art, briefing: t } })),
  setCustomer: (patch) => set((s) => ({ customer: { ...s.customer, ...patch } })),
  setPayment: (m) => set({ payment: m }),

  placeOrder: () => {
    const s = get()
    const bd = breakdownFor({
      product: s.product,
      volume: s.volume,
      weeks: s.weeks,
      quantity: s.quantity,
      addOnsMonthly: s.addOnsMonthly(),
      method: s.payment ?? 'pix',
    })
    set({
      order: {
        orderId: `MA-${nanoid(6).toUpperCase()}`,
        total: bd.total,
        paidAt: new Date().toISOString(),
      },
      step: 'success',
    })
  },

  reset: () =>
    set({
      step: 'hero',
      product: null,
      venueIds: [],
      volume: 5000,
      intensity: 0.7,
      quantity: 1,
      weeks: 12,
      addOnIds: [],
      art: INITIAL_ART,
      customer: INITIAL_CUSTOMER,
      payment: null,
      order: null,
    }),
}))

/**
 * Ordem de steps por produto. Coaster usa o fluxo completo.
 * VIP (telas/janelas) pula "upsell" (e usa `volume` step como "quantidade").
 */
export function stepsForProduct(product: ProductId | null): CheckoutStep[] {
  if (!product || product === 'coaster') return STEP_ORDER
  if (product === 'ativacao')
    return ['hero', 'venues', 'creative', 'checkout', 'success']
  // vip-telas / vip-janela
  return ['hero', 'venues', 'volume', 'duration', 'creative', 'checkout', 'success']
}

export const STEP_LABELS: Record<CheckoutStep, string> = {
  hero: 'Produto',
  venues: 'Local',
  volume: 'Volume',
  duration: 'Duração',
  upsell: 'Add-ons',
  creative: 'Arte',
  checkout: 'Pagamento',
  success: 'Pronto',
}

// Label dinâmico de step conforme produto
export function stepLabel(step: CheckoutStep, product: ProductId | null): string {
  if (step === 'volume') {
    if (product === 'vip-telas' || product === 'vip-janela') return 'Quantidade'
    return 'Volume'
  }
  if (step === 'venues') {
    if (product === 'vip-telas' || product === 'vip-janela' || product === 'ativacao')
      return 'Sala VIP'
    return 'Locais'
  }
  return STEP_LABELS[step]
}

export const STEPS_ORDER = STEP_ORDER
