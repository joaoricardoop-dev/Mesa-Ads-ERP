import { motion } from 'framer-motion'
import { useCheckoutStore } from '../../state/checkoutStore'
import { MesaAdsLogo, ArrowRight } from '../../assets/logo'
import { brl } from '../../lib/format'
import { Button } from '../ui/Button'

export function StepSuccess() {
  const order = useCheckoutStore((s) => s.order)
  const reset = useCheckoutStore((s) => s.reset)

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="relative min-h-screen overflow-hidden flex items-center justify-center"
    >
      {/* flash overlay */}
      <motion.div
        initial={{ opacity: 0.7 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="absolute inset-0 bg-mesa-neon pointer-events-none"
      />

      {/* radial bg */}
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 40%, rgba(0,230,64,0.18), rgba(0,230,64,0) 60%)',
        }}
      />

      <div className="relative z-10 mx-auto max-w-[720px] px-6 py-16 text-center">
        <MesaAdsLogo className="text-[20px]" />

        {/* Checkmark */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.15, type: 'spring', stiffness: 250, damping: 20 }}
          className="mx-auto mt-12 flex size-36 items-center justify-center rounded-full border-2 border-mesa-neon/60 bg-mesa-neon/10 shadow-[0_0_80px_-16px_rgba(0,230,64,0.6)]"
        >
          <svg viewBox="0 0 100 100" className="size-20 text-mesa-neon">
            <motion.path
              d="M25 52 L44 70 L78 32"
              stroke="currentColor"
              strokeWidth="6"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: 0.45, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            />
          </svg>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="mt-10 font-display text-[44px] lg:text-[64px] leading-[0.96] tracking-[-0.04em] text-chalk text-balance"
        >
          Sua campanha
          <br />
          <span className="italic font-serif font-normal text-chalk/80">está</span>{' '}
          nas mesas.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="mt-4 text-[15px] text-chalk/65 max-w-md mx-auto leading-relaxed"
        >
          Recebemos seu pedido. O time Mesa.ads vai entrar em contato em até 1 dia útil com
          contrato, nota e briefing de design. Produção 5 + 20 dias até o primeiro ciclo.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="mt-8 inline-flex items-center gap-6 rounded-full border border-hairline bg-ink-900/80 backdrop-blur-xl px-5 py-3"
        >
          <div>
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">Pedido</div>
            <div className="font-mono tabular text-[15px] text-mesa-neon">
              {order?.orderId ?? '—'}
            </div>
          </div>
          <span className="h-6 w-px bg-hairline" />
          <div>
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">Total</div>
            <div className="font-mono tabular text-[15px] text-chalk">
              {order ? brl(order.total) : '—'}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.4, duration: 0.5 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <Button
            size="md"
            variant="ghost"
            onClick={() => reset()}
            iconRight={<ArrowRight className="size-4" />}
          >
            Montar outra campanha
          </Button>
        </motion.div>

        <p className="mt-12 text-[11px] text-chalk/30 tracking-[0.12em] uppercase">
          Prova de veiculação · Relatório fotográfico semanal
        </p>
      </div>
    </motion.section>
  )
}
