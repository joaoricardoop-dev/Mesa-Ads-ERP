import { useCheckoutStore } from '../../state/checkoutStore'
import { StepContainer, StepHeader } from '../layout/StepContainer'
import { Button } from '../ui/Button'
import { Chip } from '../ui/Chip'
import { ArrowLeft, ArrowRight, UploadIcon, MicIcon } from '../../assets/logo'
import { DropZone } from '../creative/DropZone'
import { BriefingForm } from '../creative/BriefingForm'
import { CoasterMockup3D } from '../creative/CoasterMockup3D'
import { motion, AnimatePresence } from 'framer-motion'
import clsx from 'clsx'
import { springTight } from '../../lib/motion'

export function StepCreative() {
  const art = useCheckoutStore((s) => s.art)
  const setChoice = useCheckoutStore((s) => s.setArtChoice)
  const setFile = useCheckoutStore((s) => s.setArtFile)
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)

  const canContinue =
    art.choice === 'own' ? !!art.fileUrl : art.choice === 'agency' ? art.briefing.trim().length > 30 : false

  return (
    <StepContainer>
      <div className="mx-auto max-w-[1200px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 05 · Arte"
          title={
            <>
              Tem arte pronta
              <br />
              ou quer que a gente faça?
            </>
          }
          subtitle="Envie uma arte quadrada ou deixe o time criar a partir do briefing. Você aprova antes da produção."
        />

        {/* Choice pills */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <ChoiceCard
            selected={art.choice === 'own'}
            onSelect={() => setChoice('own')}
            icon={<UploadIcon className="size-5" />}
            title="Eu tenho a arte"
            sub="PNG, JPG ou WebP · quadrada · até 10MB"
            tone="neon"
          />
          <ChoiceCard
            selected={art.choice === 'agency'}
            onSelect={() => setChoice('agency')}
            icon={<MicIcon className="size-5" />}
            title="Criem pra mim"
            sub="O time Mesa.ads cria a partir do briefing · +5 dias úteis"
            tone="magenta"
          />
        </div>

        {/* Choice-specific area */}
        <AnimatePresence mode="wait">
          {art.choice === 'own' && (
            <motion.div
              key="own"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.4 }}
              className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-2"
            >
              <div>
                <DropZone
                  onFile={(url, name) => setFile(url, name)}
                  currentName={art.fileName}
                  currentUrl={art.fileUrl}
                />
              </div>
              <div className="relative rounded-3xl border border-hairline bg-gradient-to-br from-ink-800/60 to-ink-950/70 overflow-hidden min-h-[420px]">
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10 text-[10px] tracking-[0.22em] uppercase text-chalk/50">
                  <span>Preview · mockup 3D</span>
                  <Chip tone="neon" size="xs" dot>
                    90mm · frente
                  </Chip>
                </div>
                <CoasterMockup3D imageUrl={art.fileUrl} className="absolute inset-0" />
                <div className="absolute bottom-4 inset-x-4 z-10 text-[11px] text-chalk/45 leading-relaxed">
                  Arraste para girar. A arte aparece na face frontal; o verso recebe o branding da
                  sua marca + QR code.
                </div>
              </div>
            </motion.div>
          )}

          {art.choice === 'agency' && (
            <motion.div
              key="agency"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.4 }}
              className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-5"
            >
              <div className="lg:col-span-3">
                <BriefingForm />
              </div>
              <div className="lg:col-span-2 rounded-3xl border border-hairline bg-gradient-to-br from-ink-800/60 to-ink-950/70 overflow-hidden min-h-[380px] relative">
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10 text-[10px] tracking-[0.22em] uppercase text-chalk/50">
                  <span>Placeholder</span>
                  <Chip tone="magenta" size="xs" dot>
                    Art em breve
                  </Chip>
                </div>
                <CoasterMockup3D imageUrl={null} className="absolute inset-0" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <Button
            size="md"
            onClick={next}
            disabled={!canContinue}
            iconRight={<ArrowRight className="size-4" />}
          >
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

function ChoiceCard({
  selected,
  onSelect,
  icon,
  title,
  sub,
  tone,
}: {
  selected: boolean
  onSelect: () => void
  icon: React.ReactNode
  title: string
  sub: string
  tone: 'neon' | 'magenta'
}) {
  return (
    <motion.button
      onClick={onSelect}
      whileHover={{ y: -3 }}
      whileTap={{ scale: 0.99 }}
      transition={springTight}
      className={clsx(
        'relative overflow-hidden rounded-3xl border p-6 text-left transition-colors duration-300 ease-apple',
        'bg-gradient-to-br from-ink-800/60 to-ink-900/80',
        selected
          ? tone === 'neon'
            ? 'border-mesa-neon/60 shadow-neon-sm'
            : 'border-mesa-magenta/60 shadow-[0_0_0_1px_rgba(255,46,138,0.5),0_0_30px_-8px_rgba(255,46,138,0.55)]'
          : 'border-hairline hover:border-hairlineBold',
      )}
    >
      <div className="flex items-center gap-4">
        <div
          className={clsx(
            'flex size-12 items-center justify-center rounded-2xl border',
            tone === 'neon'
              ? 'border-mesa-neon/30 bg-mesa-neon/10 text-mesa-neon'
              : 'border-mesa-magenta/30 bg-mesa-magenta/10 text-mesa-magenta',
          )}
        >
          {icon}
        </div>
        <div className="flex-1">
          <div className="font-display text-[20px] tracking-tight text-chalk">{title}</div>
          <div className="mt-1 text-[12px] text-chalk/55">{sub}</div>
        </div>
        <div
          className={clsx(
            'size-5 rounded-full border flex items-center justify-center transition-all duration-300',
            selected
              ? tone === 'neon'
                ? 'border-mesa-neon bg-mesa-neon'
                : 'border-mesa-magenta bg-mesa-magenta'
              : 'border-chalk/20',
          )}
        >
          {selected && <span className="size-2 rounded-full bg-ink-950" />}
        </div>
      </div>
    </motion.button>
  )
}
