import { motion, AnimatePresence } from 'framer-motion'
import { useCheckoutStore } from '../../state/checkoutStore'
import { ADD_ONS } from '../../data/products'
import { StepContainer, StepHeader } from '../layout/StepContainer'
import { Button } from '../ui/Button'
import { Chip } from '../ui/Chip'
import { brl } from '../../lib/format'
import { ArrowLeft, ArrowRight, PlusIcon, CheckIcon, TvIcon, WindowIcon, MicIcon } from '../../assets/logo'
import clsx from 'clsx'
import { staggerContainer, staggerItem, springTight } from '../../lib/motion'

const iconFor = (id: string) =>
  id === 'tv' ? TvIcon : id === 'window' ? WindowIcon : MicIcon

export function StepUpsell() {
  const addOnIds = useCheckoutStore((s) => s.addOnIds)
  const toggleAddOn = useCheckoutStore((s) => s.toggleAddOn)
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)

  return (
    <StepContainer>
      <div className="mx-auto max-w-[1100px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 04 · Maximize o impacto"
          title={
            <>
              Quer somar mídia
              <br />
              no mesmo cliente?
            </>
          }
          subtitle="Add-ons premium para campanhas que precisam de mais fôlego. Disponibilidade em tempo real."
        />

        <motion.div
          variants={staggerContainer}
          initial="initial"
          animate="enter"
          className="grid grid-cols-1 gap-5 md:grid-cols-3"
        >
          {ADD_ONS.map((a) => {
            const selected = addOnIds.includes(a.id)
            const Icon = iconFor(a.icon)
            return (
              <motion.button
                key={a.id}
                variants={staggerItem}
                whileHover={{ y: -4 }}
                whileTap={{ scale: 0.985 }}
                transition={springTight}
                onClick={() => toggleAddOn(a.id)}
                className={clsx(
                  'group relative overflow-hidden rounded-3xl border p-7 text-left transition-colors duration-300 ease-apple',
                  'bg-gradient-to-br from-ink-800/60 to-ink-900/80 backdrop-blur-sm min-h-[320px] flex flex-col',
                  selected
                    ? 'border-mesa-neon/60 shadow-neon-sm'
                    : 'border-hairline hover:border-hairlineBold',
                )}
              >
                <div
                  aria-hidden
                  className="pointer-events-none absolute -right-16 -top-16 size-56 rounded-full opacity-20 transition-opacity duration-500 ease-apple group-hover:opacity-40"
                  style={{ background: `radial-gradient(closest-side, ${accentGradient(a.accent)}, transparent 70%)` }}
                />

                <div className="relative flex items-start justify-between">
                  <div className={`flex size-12 items-center justify-center rounded-2xl border border-hairline bg-chalk/5 ${accentText(a.accent)}`}>
                    <Icon className="size-5" />
                  </div>
                  <AnimatePresence>
                    {selected ? (
                      <motion.span
                        key="check"
                        initial={{ scale: 0, rotate: -30 }}
                        animate={{ scale: 1, rotate: 0 }}
                        exit={{ scale: 0 }}
                        transition={springTight}
                        className="flex size-9 items-center justify-center rounded-full bg-mesa-neon text-ink-950 shadow-neon-sm"
                      >
                        <CheckIcon className="size-4" />
                      </motion.span>
                    ) : (
                      <motion.span
                        key="plus"
                        initial={{ scale: 1 }}
                        animate={{ scale: 1 }}
                        className="flex size-9 items-center justify-center rounded-full border border-hairline bg-chalk/5 text-chalk/70"
                      >
                        <PlusIcon className="size-4" />
                      </motion.span>
                    )}
                  </AnimatePresence>
                </div>

                <h3 className="relative mt-6 font-display text-[22px] leading-tight tracking-tight text-chalk">
                  {a.label}
                </h3>
                <p className="relative mt-2 text-[13px] leading-relaxed text-chalk/60">{a.sub}</p>

                <div className="relative mt-auto pt-6 flex items-end justify-between border-t border-hairline">
                  <div>
                    <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
                      a partir de
                    </div>
                    <div className="font-mono tabular text-[22px] text-chalk mt-1">
                      {a.monthly > 0 ? `${brl(a.monthly)}/mês` : 'sob consulta'}
                    </div>
                  </div>
                  {a.availability && (
                    <Chip tone={a.accent} size="xs" className="max-w-[160px] text-right">
                      {a.availability}
                    </Chip>
                  )}
                </div>
              </motion.button>
            )
          })}
        </motion.div>

        <div className="mt-10 rounded-2xl border border-dashed border-hairline bg-chalk/[0.02] p-5 text-[13px] text-chalk/55 leading-relaxed">
          Add-ons são opcionais. Se preferir seguir só com porta-copos, continue direto para a arte.
          Você pode adicionar depois, mas disponibilidade pode mudar.
        </div>

        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <div className="hidden md:block text-[12px] text-chalk/50 px-3">
            {addOnIds.length > 0
              ? `${addOnIds.length} add-on(s)`
              : 'Nenhum add-on (pule se quiser)'}
          </div>
          <Button size="md" onClick={next} iconRight={<ArrowRight className="size-4" />}>
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

function accentText(a: string) {
  switch (a) {
    case 'magenta':
      return 'text-mesa-magenta'
    case 'amber':
      return 'text-mesa-amber'
    case 'orange':
      return 'text-mesa-orange'
    case 'ice':
      return 'text-mesa-ice'
    default:
      return 'text-mesa-neon'
  }
}

function accentGradient(a: string) {
  switch (a) {
    case 'magenta':
      return 'rgba(255,46,138,0.7)'
    case 'amber':
      return 'rgba(245,230,58,0.6)'
    case 'orange':
      return 'rgba(242,122,26,0.65)'
    case 'ice':
      return 'rgba(184,241,255,0.55)'
    default:
      return 'rgba(0,230,64,0.6)'
  }
}
