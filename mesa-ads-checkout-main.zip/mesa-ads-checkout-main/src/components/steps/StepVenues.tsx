import { motion } from 'framer-motion'
import { useState } from 'react'
import { useCheckoutStore, VIP_VENUE_ID } from '../../state/checkoutStore'
import { VENUES, venueById, sumReach, sumCapacity } from '../../data/venues'
import { neighborhoodId } from '../../data/neighborhoods'
import { StepContainer, StepHeader } from '../layout/StepContainer'
import { ManausMap } from '../venues/ManausMap'
import { VenueCard } from '../venues/VenueCard'
import { Button } from '../ui/Button'
import { Chip } from '../ui/Chip'
import { AnimatedNumber } from '../ui/AnimatedNumber'
import { num } from '../../lib/format'
import { ArrowLeft, ArrowRight, CheckIcon } from '../../assets/logo'
import { staggerContainer, staggerItem } from '../../lib/motion'

export function StepVenues() {
  const product = useCheckoutStore((s) => s.product)

  // Para produtos VIP/ativacao, usamos view dedicada (Harmony Lounge apenas).
  if (product === 'vip-telas' || product === 'vip-janela' || product === 'ativacao') {
    return <VipVenueView product={product} />
  }

  return <CoasterVenuesView />
}

// ============================================================
// Coaster: multi-select + mapa
// ============================================================
function CoasterVenuesView() {
  const venueIds = useCheckoutStore((s) => s.venueIds)
  const toggleVenue = useCheckoutStore((s) => s.toggleVenue)
  const setVenues = useCheckoutStore((s) => s.setVenues)
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)
  const reach = sumReach(venueIds)
  const capacity = sumCapacity(venueIds)

  const [filter, setFilter] = useState<string | null>(null)

  const filtered = filter
    ? VENUES.filter((v) => neighborhoodId(v.neighborhood) === filter)
    : VENUES

  const handleNeighborhoodClick = (id: string) => {
    setFilter(filter === id ? null : id)
  }

  const selectAll = () => setVenues(VENUES.map((v) => v.id))
  const clearAll = () => setVenues([])

  return (
    <StepContainer>
      <div className="mx-auto max-w-[1200px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 01 · Locais"
          title={
            <>
              Onde sua marca
              <br />
              vai aparecer.
            </>
          }
          subtitle="Escolha os bares, restaurantes e salas VIP que combinam com seu público. O volume por ciclo é calculado a partir da capacidade da sua rede."
        />

        {/* Reach metric */}
        <motion.div layout className="mb-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <ReachCard
            label="Alcance estimado"
            value={reach}
            unit="clientes/mês"
            accent
          />
          <StatCard
            label="Capacidade por ciclo"
            value={capacity}
            unit="porta-copos"
          />
          <StatCard
            label="Locais selecionados"
            value={venueIds.length}
            unit={`de ${VENUES.length}`}
          />
        </motion.div>

        {/* Map */}
        <div className="mb-10 overflow-hidden rounded-3xl border border-hairline bg-gradient-to-br from-ink-900/40 to-ink-950/60 backdrop-blur-sm">
          <div className="flex items-center justify-between border-b border-hairline px-5 py-3">
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
              Mapa ilustrativo · Manaus
            </div>
            <div className="flex items-center gap-2">
              {filter && (
                <Chip tone="neon" size="xs" dot>
                  Filtrando: {filter.replaceAll('-', ' ')}
                </Chip>
              )}
              <button
                className="text-[11px] tracking-wide text-chalk/50 hover:text-chalk transition-colors"
                onClick={() => setFilter(null)}
              >
                limpar filtro
              </button>
            </div>
          </div>
          <div className="p-4 lg:p-6">
            <ManausMap
              selectedVenueIds={venueIds}
              onNeighborhoodClick={handleNeighborhoodClick}
              className="max-h-[460px]"
            />
          </div>
        </div>

        {/* Controls */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[12px] text-chalk/50 tracking-wide">
            <span className="text-chalk">{filtered.length}</span> local(is) · clique no mapa para
            filtrar por bairro
          </div>
          <div className="flex items-center gap-2">
            <Button variant="quiet" size="sm" onClick={selectAll}>
              Selecionar todos
            </Button>
            {venueIds.length > 0 && (
              <Button variant="quiet" size="sm" onClick={clearAll}>
                Limpar
              </Button>
            )}
          </div>
        </div>

        {/* Grid of venues */}
        <motion.div
          variants={staggerContainer}
          initial="initial"
          animate="enter"
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {filtered.map((v) => (
            <motion.div key={v.id} variants={staggerItem}>
              <VenueCard
                venue={v}
                selected={venueIds.includes(v.id)}
                onToggle={() => toggleVenue(v.id)}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Footer nav */}
        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <div className="hidden md:block text-[12px] text-chalk/50 px-3">
            {venueIds.length > 0 ? `${venueIds.length} selecionado(s)` : 'Selecione ao menos 1 local'}
          </div>
          <Button
            size="md"
            onClick={next}
            disabled={venueIds.length === 0}
            iconRight={<ArrowRight className="size-4" />}
          >
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

// ============================================================
// VIP / Ativação: single venue (Harmony Lounge MAO)
// ============================================================
function VipVenueView({ product }: { product: 'vip-telas' | 'vip-janela' | 'ativacao' }) {
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)
  const venue = venueById(VIP_VENUE_ID)!

  const copy = copyFor(product)

  return (
    <StepContainer>
      <div className="mx-auto max-w-[1100px] px-6 lg:px-10">
        <StepHeader
          eyebrow={copy.eyebrow}
          title={copy.title}
          subtitle={copy.subtitle}
        />

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
          {/* Venue hero card */}
          <div className="lg:col-span-3 relative overflow-hidden rounded-3xl border border-hairline bg-gradient-to-br from-ink-800/70 to-ink-900/90 p-7 lg:p-9">
            <div
              aria-hidden
              className="pointer-events-none absolute -right-20 -top-20 size-80 rounded-full opacity-30"
              style={{
                background:
                  'radial-gradient(closest-side, rgba(184,241,255,0.4), transparent 70%)',
              }}
            />

            <div className="relative flex items-center gap-2 mb-4">
              <Chip tone="magenta" size="xs">Premium</Chip>
              <Chip tone="ice" size="xs">Aeroporto MAO</Chip>
              <Chip tone="neon" size="xs" dot>Selecionado</Chip>
            </div>
            <h2 className="relative font-display text-[32px] leading-tight tracking-[-0.02em] text-chalk text-balance">
              {venue.name}
            </h2>
            <p className="relative mt-3 text-[14px] text-chalk/65 leading-relaxed max-w-lg">
              Sala VIP exclusiva do Aeroporto de Manaus. Público executivo e viajantes,
              rotatividade diária e alta exposição da marca no contexto premium.
            </p>

            <dl className="relative mt-7 grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Metric k="Mesas" v={num(venue.mesas)} />
              <Metric k="Assentos" v={num(venue.assentos)} />
              <Metric k="Clientes/mês" v={num(venue.clientesMes)} accent />
              <Metric k="Cap. porta-copos" v={num(venue.capCoasters)} />
            </dl>
          </div>

          {/* Product format sidebar */}
          <div className="lg:col-span-2 rounded-3xl border border-hairline bg-ink-900/60 backdrop-blur-sm p-6 lg:p-7 flex flex-col">
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
              Formato escolhido
            </div>
            <div className="mt-2 font-display text-[22px] tracking-tight text-chalk">
              {copy.productLabel}
            </div>
            <p className="mt-2 text-[13px] text-chalk/60 leading-relaxed">{copy.productSub}</p>

            <ul className="mt-6 space-y-3">
              {copy.bullets.map((b) => (
                <li key={b} className="flex items-start gap-2.5 text-[13px] text-chalk/75">
                  <span className="mt-1 flex size-4 shrink-0 items-center justify-center rounded-full bg-mesa-neon/20 text-mesa-neon">
                    <CheckIcon className="size-3" />
                  </span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>

            {copy.availability && (
              <div className="mt-auto pt-6 text-[11px] tracking-wide text-chalk/50 border-t border-hairline mt-6">
                <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/40 mb-1">
                  Disponibilidade
                </div>
                {copy.availability}
              </div>
            )}
          </div>
        </div>

        {/* Footer nav */}
        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <Button size="md" onClick={next} iconRight={<ArrowRight className="size-4" />}>
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

function copyFor(product: 'vip-telas' | 'vip-janela' | 'ativacao') {
  if (product === 'vip-telas') {
    return {
      eyebrow: 'Etapa 01 · Sala VIP MAO',
      title: (
        <>
          Seu formato fica
          <br />
          na Sala VIP do aeroporto.
        </>
      ),
      subtitle:
        'Telas 55" da Harmony Lounge são veiculadas exclusivamente na Sala VIP do Aeroporto de Manaus. Public executivo, alta rotatividade.',
      productLabel: 'Telas 55" · Sala VIP MAO',
      productSub:
        '3 telas 55" disponíveis na Harmony Lounge. Loop controlado, som opcional.',
      bullets: [
        'Até 3 telas simultâneas',
        'Loop controlado de vídeos',
        'Público executivo com tempo de espera alto',
        'A partir de R$ 9.000 por ciclo de 4 semanas',
      ],
      availability: '3 telas disponíveis',
    }
  }
  if (product === 'vip-janela') {
    return {
      eyebrow: 'Etapa 01 · Sala VIP MAO',
      title: (
        <>
          Vitrine digital
          <br />
          em altura da visão.
        </>
      ),
      subtitle:
        'Janelas digitais ocupam a área visual principal da Sala VIP. Formato vertical premium, sem competição direta com anúncios digitais.',
      productLabel: 'Janelas Digitais · Sala VIP MAO',
      productSub:
        '2 janelas digitais disponíveis. Formato vertical, alto impacto.',
      bullets: [
        'Até 2 janelas simultâneas',
        'Formato vertical em altura da visão',
        'Exposição contínua ao público VIP',
        'A partir de R$ 12.000 por ciclo de 4 semanas',
      ],
      availability: 'ELMSVMAO-1 disponível · ELMSVMAO-2 ocupada até dez/26',
    }
  }
  return {
    eyebrow: 'Etapa 01 · Sala VIP MAO',
    title: (
      <>
        Live marketing
        <br />
        dentro da Sala VIP.
      </>
    ),
    subtitle:
      'Ativação física personalizada para degustação, lançamento ou experiência de marca. Espaços ELMSVMAO-1 e ELMSVMAO-2.',
    productLabel: 'Ativação Física',
    productSub: 'Valor sob consulta. Vamos preparar uma proposta personalizada.',
    bullets: [
      'Equipe dedicada no local',
      'Customização total do formato',
      'Ideal para lançamentos e degustações',
      'Prazo combinado caso-a-caso',
    ],
    availability: 'Espaços ELMSVMAO-1 e ELMSVMAO-2 · consulta em 24h',
  }
}

// ============================================================
// Compartilhados
// ============================================================
function Metric({ k, v, accent }: { k: string; v: string; accent?: boolean }) {
  return (
    <div>
      <dt className="text-[10px] tracking-[0.18em] uppercase text-chalk/40">{k}</dt>
      <dd
        className={`mt-0.5 font-mono text-[15px] tabular ${
          accent ? 'text-mesa-neon' : 'text-chalk/85'
        }`}
      >
        {v}
      </dd>
    </div>
  )
}

function ReachCard({
  label,
  value,
  unit,
  accent,
}: {
  label: string
  value: number
  unit: string
  accent?: boolean
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-hairline bg-ink-900/40 backdrop-blur-sm p-5">
      <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">{label}</div>
      <div className="mt-2 flex items-baseline gap-2">
        <AnimatedNumber
          value={value}
          className={`font-display text-[42px] leading-none tabular ${
            accent ? 'text-mesa-neon' : 'text-chalk'
          }`}
          format={(v) => num(Math.round(v))}
        />
        <span className="text-[12px] text-chalk/45">{unit}</span>
      </div>
      {accent && (
        <div
          aria-hidden
          className="absolute right-0 top-0 h-full w-24 opacity-40"
          style={{
            background:
              'radial-gradient(closest-side, rgba(0,230,64,0.3), rgba(0,230,64,0) 70%)',
          }}
        />
      )}
    </div>
  )
}

function StatCard({ label, value, unit }: { label: string; value: number; unit: string }) {
  return (
    <div className="rounded-2xl border border-hairline bg-ink-900/40 p-5">
      <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">{label}</div>
      <div className="mt-2 flex items-baseline gap-2">
        <AnimatedNumber
          value={value}
          className="font-display text-[32px] leading-none tabular text-chalk"
          format={(v) => num(Math.round(v))}
        />
        <span className="text-[12px] text-chalk/45">{unit}</span>
      </div>
    </div>
  )
}
