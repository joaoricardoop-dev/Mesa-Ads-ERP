import { useCheckoutStore } from '../../state/checkoutStore'
import { StepContainer, StepHeader } from '../layout/StepContainer'
import { TextField } from '../ui/TextField'
import { Button } from '../ui/Button'
import { ArrowLeft, CheckIcon } from '../../assets/logo'
import { PaymentPicker } from '../checkout/PaymentPicker'
import { breakdownFor, cyclesFromWeeks } from '../../lib/pricing'
import { addOnById } from '../../data/products'
import { brl } from '../../lib/format'
import { useState } from 'react'

interface FieldErrors {
  name?: string
  email?: string
  doc?: string
  phone?: string
  company?: string
}

function validate(v: Record<string, string>): FieldErrors {
  const errs: FieldErrors = {}
  if (!v.name || v.name.trim().length < 2) errs.name = 'Informe seu nome'
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v.email ?? '')) errs.email = 'E-mail inválido'
  if (!v.doc || v.doc.replace(/\D/g, '').length < 11) errs.doc = 'CPF/CNPJ inválido'
  if (!v.phone || v.phone.replace(/\D/g, '').length < 10) errs.phone = 'Telefone inválido'
  if (!v.company || v.company.trim().length < 2) errs.company = 'Informe a empresa ou marca'
  return errs
}

function formatDoc(raw: string) {
  const d = raw.replace(/\D/g, '').slice(0, 14)
  if (d.length <= 11) {
    // CPF
    return d
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
  }
  // CNPJ
  return d
    .replace(/(\d{2})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1/$2')
    .replace(/(\d{4})(\d{1,2})$/, '$1-$2')
}

function formatPhone(raw: string) {
  const d = raw.replace(/\D/g, '').slice(0, 11)
  if (d.length <= 10) {
    return d.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3').trim()
  }
  return d.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3').trim()
}

export function StepCheckout() {
  const customer = useCheckoutStore((s) => s.customer)
  const setCustomer = useCheckoutStore((s) => s.setCustomer)
  const payment = useCheckoutStore((s) => s.payment)
  const setPayment = useCheckoutStore((s) => s.setPayment)
  const placeOrder = useCheckoutStore((s) => s.placeOrder)
  const back = useCheckoutStore((s) => s.back)

  const product = useCheckoutStore((s) => s.product)
  const volume = useCheckoutStore((s) => s.volume)
  const weeks = useCheckoutStore((s) => s.weeks)
  const quantity = useCheckoutStore((s) => s.quantity)
  const addOnIds = useCheckoutStore((s) => s.addOnIds)
  const addOnsMonthly = addOnIds.reduce(
    (sum, id) => sum + (addOnById(id)?.monthly ?? 0),
    0,
  )
  const cycles = cyclesFromWeeks(weeks)

  const method = payment ?? 'pix'
  const bd = breakdownFor({
    product,
    volume,
    weeks,
    quantity,
    addOnsMonthly,
    method,
  })

  const [touched, setTouched] = useState<Record<string, boolean>>({})
  const errors = validate(customer as unknown as Record<string, string>)
  const isValid = Object.keys(errors).length === 0 && payment !== null

  const markTouched = (k: string) => setTouched((t) => ({ ...t, [k]: true }))

  return (
    <StepContainer>
      <div className="mx-auto max-w-[1200px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 06 · Dados & pagamento"
          title="Quase lá. Só falta o quem e o como."
          subtitle="Enviaremos contrato, nota fiscal e relatório semanal para o e-mail informado."
        />

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
          {/* Left: form */}
          <div className="lg:col-span-3 space-y-5">
            <div className="rounded-3xl border border-hairline bg-ink-900/50 backdrop-blur-sm p-6 lg:p-8">
              <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45 mb-5">
                Seus dados
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <TextField
                  label="Nome completo"
                  value={customer.name}
                  onValueChange={(v) => setCustomer({ name: v })}
                  onBlur={() => markTouched('name')}
                  error={touched.name ? errors.name : undefined}
                  autoComplete="name"
                />
                <TextField
                  label="E-mail"
                  type="email"
                  value={customer.email}
                  onValueChange={(v) => setCustomer({ email: v })}
                  onBlur={() => markTouched('email')}
                  error={touched.email ? errors.email : undefined}
                  autoComplete="email"
                />
                <TextField
                  label="Empresa / Marca"
                  value={customer.company}
                  onValueChange={(v) => setCustomer({ company: v })}
                  onBlur={() => markTouched('company')}
                  error={touched.company ? errors.company : undefined}
                  autoComplete="organization"
                />
                <TextField
                  label="CPF / CNPJ"
                  value={customer.doc}
                  onValueChange={(v) => setCustomer({ doc: formatDoc(v) })}
                  onBlur={() => markTouched('doc')}
                  error={touched.doc ? errors.doc : undefined}
                  inputMode="numeric"
                />
                <TextField
                  label="Telefone"
                  value={customer.phone}
                  onValueChange={(v) => setCustomer({ phone: formatPhone(v) })}
                  onBlur={() => markTouched('phone')}
                  error={touched.phone ? errors.phone : undefined}
                  inputMode="tel"
                  autoComplete="tel"
                  className="md:col-span-2"
                />
              </div>
            </div>

            <div className="rounded-3xl border border-hairline bg-ink-900/50 backdrop-blur-sm p-6 lg:p-8">
              <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45 mb-5">
                Forma de pagamento
              </div>
              <PaymentPicker
                value={payment}
                onChange={setPayment}
                baseAmount={bd.base}
                cycles={cycles}
              />
            </div>
          </div>

          {/* Right: summary */}
          <div className="lg:col-span-2">
            <div className="sticky top-6 rounded-3xl border border-hairline bg-gradient-to-br from-ink-800/70 to-ink-900/90 backdrop-blur-xl p-6 lg:p-7">
              <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
                Resumo do pedido
              </div>

              <div className="mt-4 space-y-2 text-[13px] border-b border-hairline pb-5">
                <Row k="Subtotal" v={brl(bd.base)} />
                {bd.paymentDiscount > 0 && (
                  <Row k="Desconto Pix" v={`- ${brl(bd.paymentDiscount)}`} accent />
                )}
              </div>

              <div className="mt-5 flex items-end justify-between">
                <div>
                  <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
                    Total
                  </div>
                  <div className="mt-1 font-display text-[36px] leading-none tracking-[-0.03em] tabular text-chalk">
                    {brl(bd.total)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
                    {method === 'pix'
                      ? 'À vista'
                      : method === 'boleto'
                        ? `${bd.installments}× boleto`
                        : `${bd.installments}× cartão`}
                  </div>
                  {bd.installments > 1 && (
                    <div className="mt-1 font-mono tabular text-[14px] text-chalk/80">
                      {brl(bd.installmentValue)}
                    </div>
                  )}
                </div>
              </div>

              <Button
                fullWidth
                size="lg"
                onClick={placeOrder}
                disabled={!isValid}
                className="mt-6"
                iconRight={<CheckIcon className="size-4" />}
              >
                Confirmar e pagar
              </Button>

              <p className="mt-4 text-[11px] text-chalk/40 leading-relaxed">
                Pagamento 100% antes da veiculação. Produção de arte em 5 dias + 20 dias de
                impressão. Contrato e nota fiscal por e-mail.
              </p>
            </div>
          </div>
        </div>

        <div className="sticky bottom-24 xl:bottom-10 mt-10 flex items-center">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

function Row({ k, v, accent }: { k: string; v: string; accent?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-chalk/55">{k}</span>
      <span className={`font-mono tabular ${accent ? 'text-mesa-neon' : 'text-chalk/85'}`}>{v}</span>
    </div>
  )
}
