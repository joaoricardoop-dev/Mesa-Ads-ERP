import { useCheckoutStore } from '../../state/checkoutStore'
import { StepContainer, StepHeader } from '../layout/StepContainer'
import { Slider } from '../ui/Slider'
import {
  VOLUME_STEPS,
  snapTo,
  lookupTotal,
  totalCoastersForCampaign,
  VIP_INVENTORY,
  lookupVipTotal,
} from '../../data/pricing'
import { num, brl, plural } from '../../lib/format'
import { AnimatedNumber } from '../ui/AnimatedNumber'
import { Button } from '../ui/Button'
import { ArrowLeft, ArrowRight, PlusIcon, MinusIcon } from '../../assets/logo'
import { Chip } from '../ui/Chip'
import { sumCapacity } from '../../data/venues'
import { motion } from 'framer-motion'
import clsx from 'clsx'

export function StepVolume() {
  const product = useCheckoutStore((s) => s.product)
  if (product === 'vip-telas' || product === 'vip-janela') {
    return <VipQuantityView product={product} />
  }
  return <CoasterVolumeView />
}

// ============================================================
// Coaster: volume = capacidade × intensidade (auto)
// ============================================================
function CoasterVolumeView() {
  const venueIds = useCheckoutStore((s) => s.venueIds)
  const volume = useCheckoutStore((s) => s.volume)
  const intensity = useCheckoutStore((s) => s.intensity)
  const weeks = useCheckoutStore((s) => s.weeks)
  const setIntensity = useCheckoutStore((s) => s.setIntensity)
  const setVolume = useCheckoutStore((s) => s.setVolume)
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)

  const capacity = sumCapacity(venueIds)
  const total = lookupTotal(volume, weeks)
  const totalCoasters = totalCoastersForCampaign(volume, weeks)
  const unit = totalCoasters > 0 ? total / totalCoasters : 0
  const utilizationPct = capacity > 0 ? Math.round((volume / capacity) * 100) : 0
  const intensityPct = Math.round(intensity * 100)

  return (
    <StepContainer>
      <div className="mx-auto max-w-[980px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 02 · Volume por ciclo"
          title={
            <>
              Quantos porta-copos por
              <br /> ciclo de 4 semanas?
            </>
          }
          subtitle="Calculamos automaticamente com base na capacidade dos restaurantes que você escolheu. Ajuste a intensidade para ter mais ou menos frequência."
        />

        <div className="rounded-3xl border border-hairline bg-ink-900/50 backdrop-blur-sm p-8 lg:p-12">
          {/* Capacity readout */}
          <div className="mb-8 flex flex-wrap items-end justify-between gap-6 border-b border-hairline pb-6">
            <div>
              <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">
                Capacidade da rede selecionada
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="font-mono text-[32px] tabular text-chalk">
                  {num(capacity)}
                </span>
                <span className="text-[13px] text-chalk/50">porta-copos/ciclo · máx.</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">Utilização</div>
              <div className="mt-2 font-mono text-[24px] tabular text-mesa-neon">{utilizationPct}%</div>
            </div>
          </div>

          {/* Main number */}
          <motion.div
            key={volume}
            initial={{ opacity: 0.4 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center text-center mb-10"
          >
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">Sugestão de volume / ciclo</div>
            <div className="mt-4 flex items-baseline gap-3">
              <AnimatedNumber
                value={volume}
                className="font-display text-mega leading-none tracking-[-0.05em] text-chalk tabular"
                format={(v) => num(Math.round(v))}
              />
              <span className="text-[20px] text-chalk/45">porta-copos</span>
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-[12px] text-chalk/55">
              <Chip tone="neon" size="xs" dot>
                Capacidade × {intensityPct}% frequência
              </Chip>
              {capacity === 0 && (
                <Chip tone="magenta" size="xs">
                  Volte e selecione pelo menos 1 local
                </Chip>
              )}
            </div>
          </motion.div>

          {/* Intensity slider */}
          <div className="mb-8">
            <div className="mb-2 flex items-center justify-between text-[12px] tracking-wide uppercase text-chalk/55">
              <span>Intensidade de veiculação</span>
              <span className="font-mono tabular text-chalk/85">{intensityPct}%</span>
            </div>
            <Slider
              min={25}
              max={100}
              step={5}
              value={intensityPct}
              onChange={(v) => setIntensity(v / 100)}
              accent="neon"
              ticks={[25, 50, 75, 100]}
            />
            <div className="mt-3 flex items-center justify-between text-[11px] text-chalk/40">
              <span>Leve — 25%</span>
              <span>Padrão — 70%</span>
              <span>Cheio — 100%</span>
            </div>
          </div>

          {/* Manual override */}
          <details className="group mb-4 rounded-2xl border border-hairline bg-ink-800/40 px-5 py-4">
            <summary className="flex cursor-pointer items-center justify-between text-[12px] tracking-wide text-chalk/60 hover:text-chalk transition-colors">
              <span>Ajustar volume manualmente</span>
              <span className="text-chalk/40 group-open:rotate-180 transition-transform">▾</span>
            </summary>
            <div className="mt-5">
              <Slider
                min={VOLUME_STEPS[0]}
                max={VOLUME_STEPS[VOLUME_STEPS.length - 1]}
                step={1000}
                value={volume}
                onChange={(v) => setVolume(snapTo(v, VOLUME_STEPS))}
                ticks={[...VOLUME_STEPS]}
                accent="neon"
              />
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                {[1000, 5000, 10000, 15000, 20000].map((v) => (
                  <button
                    key={v}
                    onClick={() => setVolume(v)}
                    className={clsx(
                      'rounded-full px-4 py-1.5 text-[12px] tracking-wide transition-colors duration-200 ease-apple',
                      volume === v
                        ? 'bg-mesa-neon text-ink-950 font-semibold'
                        : 'bg-chalk/5 text-chalk/70 hover:bg-chalk/10 border border-hairline',
                    )}
                  >
                    {num(v)}
                  </button>
                ))}
              </div>
            </div>
          </details>

          {/* Breakdown */}
          <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-3">
            <Stat
              label="Total de porta-copos"
              value={num(totalCoasters)}
              sub={`${weeks / 4} ciclo(s) × ${num(volume)}`}
            />
            <Stat label="Preço por porta-copo" value={brl(unit)} sub="já com descontos" accent />
            <Stat
              label="Total estimado"
              value={brl(total)}
              sub={`${weeks} semanas`}
              strong
            />
          </div>
        </div>

        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <Button
            size="md"
            onClick={next}
            disabled={capacity === 0}
            iconRight={<ArrowRight className="size-4" />}
          >
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

// ============================================================
// VIP: quantidade de unidades (telas ou janelas)
// ============================================================
function VipQuantityView({ product }: { product: 'vip-telas' | 'vip-janela' }) {
  const quantity = useCheckoutStore((s) => s.quantity)
  const weeks = useCheckoutStore((s) => s.weeks)
  const setQuantity = useCheckoutStore((s) => s.setQuantity)
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)

  const inventory = VIP_INVENTORY[product]
  const max = inventory.max

  const pricePerUnit = lookupVipTotal(product, weeks, 1)
  const totalPrice = lookupVipTotal(product, weeks, quantity)

  const change = (delta: number) => {
    setQuantity(Math.max(1, Math.min(max, quantity + delta)))
  }

  const label = product === 'vip-telas' ? 'telas 55"' : 'janelas digitais'

  return (
    <StepContainer>
      <div className="mx-auto max-w-[980px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 02 · Quantidade"
          title={
            <>
              Quantas {label}
              <br />
              na Sala VIP?
            </>
          }
          subtitle={`A Sala VIP MAO comporta até ${max} ${label} simultaneamente. Ajuste a quantidade conforme a presença desejada.`}
        />

        <div className="rounded-3xl border border-hairline bg-ink-900/50 backdrop-blur-sm p-8 lg:p-14">
          {/* Main number */}
          <div className="flex flex-col items-center text-center mb-10">
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">Quantidade</div>
            <div className="mt-4 flex items-baseline gap-3">
              <motion.span
                key={quantity}
                initial={{ y: 8, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="font-display text-mega leading-none tracking-[-0.05em] text-chalk tabular"
              >
                {quantity}
              </motion.span>
              <span className="text-[20px] text-chalk/45">{label}</span>
            </div>
            <div className="mt-3 text-[13px] text-chalk/55">
              {quantity} de {max} {plural(max, 'disponível', 'disponíveis')}
            </div>
          </div>

          {/* +/- stepper */}
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={() => change(-1)}
              disabled={quantity <= 1}
              className="flex size-14 items-center justify-center rounded-full border border-hairline bg-chalk/5 text-chalk transition-all hover:bg-chalk/10 disabled:opacity-30"
              aria-label="Diminuir quantidade"
            >
              <MinusIcon className="size-5" />
            </button>

            {/* Visual units */}
            <div className="flex items-center gap-2">
              {Array.from({ length: max }).map((_, i) => {
                const active = i < quantity
                return (
                  <motion.div
                    key={i}
                    animate={{
                      scale: active ? 1 : 0.9,
                      opacity: active ? 1 : 0.35,
                    }}
                    transition={{ type: 'spring', stiffness: 400, damping: 28 }}
                    className={clsx(
                      'flex items-center justify-center rounded-xl transition-all',
                      product === 'vip-telas'
                        ? 'h-16 w-24 border-2'
                        : 'h-20 w-14 border-2',
                      active
                        ? 'border-mesa-neon bg-mesa-neon/10 shadow-neon-sm'
                        : 'border-hairline bg-chalk/[0.02]',
                    )}
                  >
                    <span className={clsx('text-[10px] tracking-[0.18em] uppercase', active ? 'text-mesa-neon' : 'text-chalk/30')}>
                      {product === 'vip-telas' ? '55"' : 'JAN'}
                    </span>
                  </motion.div>
                )
              })}
            </div>

            <button
              onClick={() => change(1)}
              disabled={quantity >= max}
              className="flex size-14 items-center justify-center rounded-full border border-mesa-neon/40 bg-mesa-neon/10 text-mesa-neon transition-all hover:bg-mesa-neon/20 disabled:opacity-30"
              aria-label="Aumentar quantidade"
            >
              <PlusIcon className="size-5" />
            </button>
          </div>

          {/* Preview chips */}
          <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-3">
            <Stat
              label="Preço por unidade"
              value={brl(pricePerUnit)}
              sub={`${weeks} sem`}
            />
            <Stat
              label="Unidades"
              value={`${quantity}×`}
              sub={label}
              accent
            />
            <Stat
              label="Total estimado"
              value={brl(totalPrice)}
              sub={`${weeks} semanas`}
              strong
            />
          </div>
        </div>

        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <Button size="md" onClick={next} iconRight={<ArrowRight className="size-4" />}>
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

function Stat({
  label,
  value,
  sub,
  accent,
  strong,
}: {
  label: string
  value: string
  sub?: string
  accent?: boolean
  strong?: boolean
}) {
  return (
    <div className="rounded-2xl border border-hairline bg-ink-800/40 p-5">
      <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">{label}</div>
      <div
        className={clsx(
          'mt-2 font-mono tabular',
          strong && 'text-[28px] text-chalk',
          accent && !strong && 'text-[22px] text-mesa-neon',
          !strong && !accent && 'text-[22px] text-chalk/90',
        )}
      >
        {value}
      </div>
      {sub && <div className="mt-1 text-[11px] text-chalk/40">{sub}</div>}
    </div>
  )
}
