import { motion } from 'framer-motion'
import { useCheckoutStore } from '../../state/checkoutStore'
import { PRODUCTS } from '../../data/products'
import { HERO_COPY, STATS } from '../../data/faq'
import { CoasterScene } from '../hero/CoasterScene'
import { MesaAdsLogo, ArrowRight } from '../../assets/logo'
import { Button } from '../ui/Button'
import { Chip } from '../ui/Chip'
import { ThemeToggle } from '../ui/ThemeToggle'
import { stepVariants, staggerContainer, staggerItem } from '../../lib/motion'
import clsx from 'clsx'

export function StepHero() {
  const setProduct = useCheckoutStore((s) => s.setProduct)
  const next = useCheckoutStore((s) => s.next)

  const onPick = (id: (typeof PRODUCTS)[number]['id']) => {
    setProduct(id)
    next()
  }

  return (
    <motion.section
      variants={stepVariants}
      initial="initial"
      animate="enter"
      exit="exit"
      className="relative min-h-screen overflow-hidden"
    >
      {/* 3D scene absolute layer — levemente apagado pra não competir com o texto */}
      <div
        className="pointer-events-auto absolute inset-0 z-0"
        style={{ opacity: 0.75, filter: 'saturate(0.9)' }}
      >
        <CoasterScene className="h-full w-full" />
      </div>
      {/* Soft veil radial sutil para integrar com o fundo */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[1]"
        style={{
          background:
            'radial-gradient(ellipse at center, rgba(4,4,5,0) 45%, rgba(4,4,5,0.3) 90%)',
        }}
      />

      {/* top bar (mobile: inline with progress; desktop: free) — respeita rail fixo de 124px */}
      <div className="relative z-20 flex items-center justify-between px-6 lg:pl-[148px] lg:pr-12 pt-6 lg:pt-8">
        <MesaAdsLogo className="text-[17px] lg:hidden" />
        <div className="hidden lg:flex items-center gap-4 text-[11px] tracking-[0.22em] uppercase text-chalk/50">
          <span className="size-1.5 rounded-full bg-mesa-neon animate-pulse-neon" />
          auto-checkout · mesa.ads
        </div>
        <div className="flex items-center gap-3">
          <Chip tone="neon" dot size="sm" className="hidden lg:inline-flex">
            Manaus, AM · rede ativa
          </Chip>
          <ThemeToggle variant="icon" />
        </div>
      </div>

      {/* Headline grid — respeita rail fixo de 124px via padding lateral */}
      <motion.div
        variants={staggerContainer}
        initial="initial"
        animate="enter"
        className="relative z-10 mx-auto grid w-full max-w-[1400px] items-center gap-10 px-6 lg:pl-[148px] lg:pr-12 pt-10 pb-24 lg:pt-20 lg:grid-cols-12 lg:gap-8"
      >
        <div className="lg:col-span-7 xl:col-span-6">
          <motion.div variants={staggerItem} className="mb-5">
            <span className="text-[11px] tracking-[0.22em] uppercase text-mesa-neon/90">
              {HERO_COPY.eyebrow}
            </span>
          </motion.div>

          <motion.h1
            variants={staggerItem}
            className="font-display text-mega font-medium tracking-[-0.04em] text-chalk text-balance"
          >
            Sua marca na mesa
            <br />
            <span className="italic font-serif font-normal text-chalk/90"> do seu </span>
            cliente.
          </motion.h1>

          <motion.p
            variants={staggerItem}
            className="mt-6 max-w-[40ch] text-[15px] lg:text-[17px] text-chalk/65 leading-relaxed"
          >
            74 minutos de atenção real por refeição contra 1,9 segundo em mídia digital. Escolha
            formato, locais e prazo — a campanha vai pras mesas.
          </motion.p>

          <motion.div variants={staggerItem} className="mt-10 flex flex-wrap items-center gap-3">
            <Button
              size="lg"
              onClick={() => onPick('coaster')}
              iconRight={<ArrowRight className="size-4" />}
            >
              {HERO_COPY.ctaPrimary}
            </Button>
            <Button
              size="lg"
              variant="ghost"
              onClick={() => {
                setProduct('coaster')
                useCheckoutStore.getState().goTo('venues')
              }}
            >
              Ver rede de locais
            </Button>
          </motion.div>

          {/* Stats row */}
          <motion.ul
            variants={staggerContainer}
            className="mt-14 grid grid-cols-2 gap-x-6 gap-y-5 lg:grid-cols-4 max-w-2xl"
          >
            {STATS.map((s) => (
              <motion.li key={s.label} variants={staggerItem}>
                <div className="font-display text-[28px] leading-none text-chalk tabular font-medium">
                  {s.value}
                </div>
                <div className="mt-1.5 text-[11px] tracking-[0.1em] uppercase text-chalk/55">
                  {s.label}
                </div>
                <div className="text-[11px] text-chalk/35">{s.sub}</div>
              </motion.li>
            ))}
          </motion.ul>
        </div>

        {/* Right: product cards */}
        <motion.div variants={staggerItem} className="lg:col-span-5 xl:col-span-6 relative">
          <div
            className="pointer-events-none absolute -inset-10 rounded-[3rem] opacity-70"
            style={{
              background:
                'radial-gradient(circle at 50% 30%, rgba(0,230,64,0.10), rgba(0,0,0,0) 60%)',
            }}
          />
          <div className="relative z-10 rounded-3xl border border-hairline bg-ink-900/60 p-5 backdrop-blur-xl shadow-soft">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-[10px] tracking-[0.22em] uppercase text-chalk/50">
                Formatos
              </span>
              <span className="text-[10px] tracking-[0.22em] uppercase text-chalk/30">
                ↳ escolha um
              </span>
            </div>
            <ul className="space-y-2.5">
              {PRODUCTS.map((p) => (
                <ProductPill key={p.id} p={p} onClick={() => onPick(p.id)} />
              ))}
            </ul>
            <div className="mt-5 rounded-2xl border border-dashed border-hairline/80 bg-white/[.02] px-4 py-3 text-[12px] leading-relaxed text-chalk/55">
              Ciclo padrão <span className="text-chalk">4 semanas</span>. Pix{' '}
              <span className="text-mesa-neon">-5%</span>, boleto parcelado por ciclo, cartão em{' '}
              <span className="text-chalk">3×</span> sem juros.
            </div>
          </div>
        </motion.div>
      </motion.div>
    </motion.section>
  )
}

function ProductPill({
  p,
  onClick,
}: {
  p: (typeof PRODUCTS)[number]
  onClick: () => void
}) {
  return (
    <li>
      <motion.button
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.99 }}
        onClick={onClick}
        className={clsx(
          'group relative w-full overflow-hidden rounded-2xl border border-hairline bg-gradient-to-br from-ink-800/70 to-ink-900/70',
          'px-4 py-3.5 text-left transition-colors duration-300 hover:border-hairlineBold',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-mesa-neon/70',
        )}
      >
        <span
          aria-hidden
          className="absolute -right-6 -top-6 size-20 rounded-full opacity-0 transition-opacity duration-500 ease-apple group-hover:opacity-50"
          style={{
            background: `radial-gradient(closest-side, ${accentHex(p.accent)}, transparent 70%)`,
          }}
        />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-[17px] tracking-tight text-chalk">{p.name}</span>
              <Chip tone={p.accent} size="xs">
                {p.tag}
              </Chip>
            </div>
            <p className="mt-1 text-[13px] text-chalk/55 leading-snug max-w-sm">{p.tagline}</p>
            {p.fromPrice && (
              <p className="mt-1.5 text-[11px] tracking-wider uppercase text-chalk/35">
                {p.fromPrice}
              </p>
            )}
          </div>
          <ArrowRight className="size-4 text-chalk/40 translate-x-0 transition-transform duration-300 ease-apple group-hover:translate-x-1.5 group-hover:text-chalk" />
        </div>
      </motion.button>
    </li>
  )
}

function accentHex(a: string) {
  switch (a) {
    case 'neon':
      return 'rgba(0,230,64,0.6)'
    case 'magenta':
      return 'rgba(255,46,138,0.55)'
    case 'amber':
      return 'rgba(245,230,58,0.5)'
    case 'orange':
      return 'rgba(242,122,26,0.55)'
    case 'ice':
      return 'rgba(184,241,255,0.5)'
    default:
      return 'rgba(255,255,255,0.3)'
  }
}
