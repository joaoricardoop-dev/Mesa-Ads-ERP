import { useCheckoutStore } from '../../state/checkoutStore'
import { StepContainer, StepHeader } from '../layout/StepContainer'
import { Slider } from '../ui/Slider'
import {
  WEEK_STEPS,
  snapTo,
  lookupTotal,
  lookupVipTotal,
  prazoDiscountPct,
} from '../../data/pricing'
import { brl, plural } from '../../lib/format'
import { Button } from '../ui/Button'
import { ArrowLeft, ArrowRight, PlusIcon, MinusIcon } from '../../assets/logo'
import { AnimatedNumber } from '../ui/AnimatedNumber'
import { motion } from 'framer-motion'
import { Chip } from '../ui/Chip'
import clsx from 'clsx'

export function StepDuration() {
  const weeks = useCheckoutStore((s) => s.weeks)
  const volume = useCheckoutStore((s) => s.volume)
  const quantity = useCheckoutStore((s) => s.quantity)
  const product = useCheckoutStore((s) => s.product)
  const setWeeks = useCheckoutStore((s) => s.setWeeks)
  const next = useCheckoutStore((s) => s.next)
  const back = useCheckoutStore((s) => s.back)

  const cycles = Math.max(1, Math.round(weeks / 4))

  // Total depende do produto
  let total = 0
  let discountNote: string | null = null
  if (product === 'coaster') {
    total = lookupTotal(volume, weeks)
  } else if (product === 'vip-telas' || product === 'vip-janela') {
    total = lookupVipTotal(product, weeks, quantity)
    const d = prazoDiscountPct(product, weeks)
    if (d > 0) discountNote = `Faixa de desconto -${d}% já aplicada`
  }
  const monthlyAvg = total / cycles

  const changeCycle = (delta: number) => {
    const c = Math.max(1, Math.min(13, cycles + delta))
    setWeeks(c * 4)
  }

  return (
    <StepContainer>
      <div className="mx-auto max-w-[980px] px-6 lg:px-10">
        <StepHeader
          eyebrow="Etapa 03 · Duração"
          title={
            <>
              Por quanto tempo
              <br />
              no ar?
            </>
          }
          subtitle="Cada ciclo é de 4 semanas padronizadas. Prazos maiores ativam descontos progressivos já embutidos."
        />

        <div className="rounded-3xl border border-hairline bg-ink-900/50 backdrop-blur-sm p-8 lg:p-12">
          <div className="flex flex-col items-center text-center mb-10">
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">Duração</div>
            <div className="mt-4 flex items-baseline gap-3">
              <AnimatedNumber
                value={weeks}
                className="font-display text-mega leading-none tracking-[-0.05em] text-chalk tabular"
              />
              <span className="text-[20px] text-chalk/45">semanas</span>
            </div>
            <div className="mt-3 text-[13px] text-chalk/60">
              <span className="font-mono tabular">{cycles}</span>{' '}
              {plural(cycles, 'ciclo', 'ciclos')} de 4 semanas
            </div>
            {discountNote && (
              <Chip tone="neon" size="xs" dot className="mt-3">
                {discountNote}
              </Chip>
            )}
          </div>

          <Slider
            min={WEEK_STEPS[0]}
            max={WEEK_STEPS[WEEK_STEPS.length - 1]}
            step={4}
            value={weeks}
            onChange={(v) => setWeeks(snapTo(v, WEEK_STEPS))}
            ticks={[...WEEK_STEPS]}
            accent="neon"
          />

          <div className="mt-3 flex items-center justify-between text-[11px] text-chalk/40 font-mono tabular">
            <span>4 sem</span>
            <span>52 sem</span>
          </div>

          {/* +/- cycles */}
          <div className="mt-10 flex items-center justify-center gap-5">
            <button
              onClick={() => changeCycle(-1)}
              disabled={cycles === 1}
              className="flex size-11 items-center justify-center rounded-full border border-hairline bg-chalk/5 text-chalk/85 transition-all hover:bg-chalk/10 disabled:opacity-30"
              aria-label="Menos um ciclo"
            >
              <MinusIcon className="size-4" />
            </button>
            <div className="flex items-baseline gap-1 min-w-[180px] justify-center">
              <motion.span
                key={cycles}
                initial={{ y: 6, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="font-display text-[44px] leading-none tabular"
              >
                {cycles}
              </motion.span>
              <span className="text-[13px] text-chalk/50">{plural(cycles, 'ciclo', 'ciclos')}</span>
            </div>
            <button
              onClick={() => changeCycle(1)}
              disabled={cycles === 13}
              className="flex size-11 items-center justify-center rounded-full border border-mesa-neon/40 bg-mesa-neon/10 text-mesa-neon transition-all hover:bg-mesa-neon/20 disabled:opacity-30"
              aria-label="Mais um ciclo"
            >
              <PlusIcon className="size-4" />
            </button>
          </div>

          {/* Timeline visualizer */}
          <div
            className="mt-10 grid gap-1.5"
            style={{ gridTemplateColumns: 'repeat(13, minmax(0, 1fr))' }}
          >
            {Array.from({ length: 13 }).map((_, i) => {
              const active = i < cycles
              return (
                <div
                  key={i}
                  className={clsx(
                    'h-10 rounded-md transition-all duration-300 ease-apple',
                    active
                      ? 'bg-gradient-to-b from-mesa-neon/40 to-mesa-neon/15 border border-mesa-neon/50'
                      : 'bg-chalk/[0.03] border border-hairline',
                  )}
                />
              )
            })}
          </div>
          <div
            className="mt-2 grid gap-1.5 text-[9px] font-mono text-chalk/35 text-center"
            style={{ gridTemplateColumns: 'repeat(13, minmax(0, 1fr))' }}
          >
            {Array.from({ length: 13 }).map((_, i) => (
              <span key={i}>{(i + 1) * 4}</span>
            ))}
          </div>

          <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-2">
            <Stat label="Média por ciclo" value={brl(monthlyAvg)} sub={`4 semanas`} />
            <Stat label="Total estimado" value={brl(total)} sub={`${weeks} semanas`} strong />
          </div>
        </div>

        <div className="sticky bottom-24 xl:bottom-10 mt-12 flex items-center justify-between rounded-full border border-hairline bg-ink-950/80 backdrop-blur-xl px-3 py-2">
          <Button variant="ghost" size="md" onClick={back} iconLeft={<ArrowLeft className="size-4" />}>
            Voltar
          </Button>
          <Button size="md" onClick={next} iconRight={<ArrowRight className="size-4" />}>
            Continuar
          </Button>
        </div>
      </div>
    </StepContainer>
  )
}

function Stat({
  label,
  value,
  sub,
  strong,
}: {
  label: string
  value: string
  sub?: string
  strong?: boolean
}) {
  return (
    <div className="rounded-2xl border border-hairline bg-ink-800/40 p-5">
      <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/45">{label}</div>
      <div
        className={`mt-2 font-mono tabular ${
          strong ? 'text-[28px] text-chalk' : 'text-[22px] text-chalk/90'
        }`}
      >
        {value}
      </div>
      {sub && <div className="mt-1 text-[11px] text-chalk/40">{sub}</div>}
    </div>
  )
}
