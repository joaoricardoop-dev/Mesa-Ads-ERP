import clsx from 'clsx'
import { motion } from 'framer-motion'
import {
  stepsForProduct,
  stepLabel,
  useCheckoutStore,
} from '../../state/checkoutStore'
import type { CheckoutStep } from '../../types'
import { MesaAdsLogo } from '../../assets/logo'
import { ThemeToggle } from '../ui/ThemeToggle'

export function ProgressRail() {
  const step = useCheckoutStore((s) => s.step)
  const product = useCheckoutStore((s) => s.product)
  const goTo = useCheckoutStore((s) => s.goTo)

  const visible: CheckoutStep[] = stepsForProduct(product).filter((s) => s !== 'success')
  const idx = visible.indexOf(step)

  return (
    <>
      {/* Desktop rail */}
      <aside
        className="fixed left-0 top-0 z-30 hidden h-screen w-[124px] flex-col justify-between border-r border-hairline bg-ink-950/60 px-5 py-7 backdrop-blur-sm lg:flex"
        aria-label="Etapas do checkout"
      >
        <div className="flex items-center gap-2 text-[15px]">
          <MesaAdsLogo />
        </div>

        <ol className="flex flex-col gap-3">
          {visible.map((s, i) => {
            const state = i < idx ? 'done' : i === idx ? 'active' : 'idle'
            return (
              <li key={s} className="flex items-center gap-2.5">
                <button
                  type="button"
                  aria-current={state === 'active' ? 'step' : undefined}
                  onClick={() => {
                    if (i <= idx) goTo(s)
                  }}
                  disabled={i > idx}
                  className={clsx(
                    'relative shrink-0 size-2.5 rounded-full border transition-all ease-apple duration-300',
                    state === 'idle' && 'border-chalk/15 bg-chalk/5',
                    state === 'active' && 'border-mesa-neon bg-mesa-neon shadow-neon-sm',
                    state === 'done' && 'border-mesa-neon/40 bg-mesa-neon/60',
                  )}
                >
                  {state === 'active' && (
                    <motion.span
                      layoutId="rail-active"
                      className="absolute inset-0 rounded-full bg-mesa-neon"
                      style={{ filter: 'blur(8px)', opacity: 0.6 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    />
                  )}
                </button>
                <span
                  className={clsx(
                    'text-[11px] tracking-[0.08em] uppercase transition-colors duration-300',
                    state === 'active' ? 'text-chalk' : 'text-chalk/40',
                  )}
                >
                  {stepLabel(s, product)}
                </span>
              </li>
            )
          })}
        </ol>

        <div className="flex flex-col items-start gap-4">
          <ThemeToggle variant="icon" />
          <div className="text-[10px] tracking-[0.2em] uppercase text-chalk/30">
            Manaus · AM
          </div>
        </div>
      </aside>

      {/* Mobile dots */}
      <div className="fixed top-0 inset-x-0 z-30 flex items-center justify-between px-5 pt-4 pb-3 border-b border-hairline bg-ink-950/70 backdrop-blur-xl lg:hidden">
        <MesaAdsLogo className="text-[15px]" />
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            {visible.map((s, i) => {
              const active = i === idx
              const done = i < idx
              return (
                <div
                  key={s}
                  className={clsx(
                    'h-1 rounded-full transition-all duration-500 ease-apple',
                    active ? 'w-6 bg-mesa-neon' : done ? 'w-3 bg-mesa-neon/50' : 'w-3 bg-chalk/15',
                  )}
                />
              )
            })}
          </div>
          <ThemeToggle variant="icon" className="size-8" />
        </div>
      </div>
    </>
  )
}
