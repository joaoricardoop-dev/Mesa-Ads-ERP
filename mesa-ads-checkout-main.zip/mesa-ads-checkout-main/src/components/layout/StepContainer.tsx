import clsx from 'clsx'
import { motion } from 'framer-motion'
import { stepVariants } from '../../lib/motion'

interface Props {
  children: React.ReactNode
  className?: string
  /** when true, centers vertically in the viewport */
  fullHeight?: boolean
}

export function StepContainer({ children, className, fullHeight }: Props) {
  return (
    <motion.section
      variants={stepVariants}
      initial="initial"
      animate="enter"
      exit="exit"
      className={clsx(
        'relative z-10 w-full',
        fullHeight ? 'min-h-[calc(100vh-64px)] flex items-center lg:min-h-screen' : 'py-16 lg:py-20',
        className,
      )}
    >
      {children}
    </motion.section>
  )
}

export function StepHeader({
  eyebrow,
  title,
  subtitle,
  className,
}: {
  eyebrow?: string
  title: React.ReactNode
  subtitle?: React.ReactNode
  className?: string
}) {
  return (
    <header className={clsx('mb-10 lg:mb-14', className)}>
      {eyebrow && (
        <div className="mb-3 inline-flex items-center gap-2 text-[11px] tracking-[0.2em] uppercase text-mesa-neon/80">
          <span className="size-1 rounded-full bg-mesa-neon" />
          {eyebrow}
        </div>
      )}
      <h1 className="font-display text-title text-chalk text-balance">{title}</h1>
      {subtitle && <p className="mt-4 max-w-xl text-chalk/60 text-[15px] leading-relaxed">{subtitle}</p>}
    </header>
  )
}
