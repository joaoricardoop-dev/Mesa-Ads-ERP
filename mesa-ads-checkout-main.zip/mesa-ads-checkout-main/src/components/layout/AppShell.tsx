import clsx from 'clsx'
import { useEffect } from 'react'
import { useCheckoutStore } from '../../state/checkoutStore'
import { ProgressRail } from './ProgressRail'
import { OrderSummary } from './OrderSummary'

interface Props {
  children: React.ReactNode
}

export function AppShell({ children }: Props) {
  const step = useCheckoutStore((s) => s.step)
  const hideChrome = step === 'success'
  // Hero não exibe OrderSummary, então não reservamos 360px à direita.
  const showSummaryPad = !hideChrome && step !== 'hero'
  // Hero usa layout próprio full-bleed; outros steps têm o rail + padding vertical.
  const showRailPad = !hideChrome && step !== 'hero'

  // Track cursor for spotlight effect
  useEffect(() => {
    const handler = (e: PointerEvent) => {
      document.documentElement.style.setProperty('--mx', `${e.clientX}px`)
      document.documentElement.style.setProperty('--my', `${e.clientY}px`)
    }
    window.addEventListener('pointermove', handler)
    return () => window.removeEventListener('pointermove', handler)
  }, [])

  return (
    <div className="relative min-h-screen grain">
      <div className="spotlight" aria-hidden />

      {/* ambient gradient orbs */}
      <div
        aria-hidden
        className="pointer-events-none fixed -top-40 -left-32 h-[520px] w-[520px] rounded-full"
        style={{
          background:
            'radial-gradient(closest-side, rgba(0,230,64,0.10), rgba(0,230,64,0) 70%)',
          filter: 'blur(30px)',
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none fixed -bottom-40 -right-32 h-[520px] w-[520px] rounded-full"
        style={{
          background:
            'radial-gradient(closest-side, rgba(255,46,138,0.10), rgba(255,46,138,0) 70%)',
          filter: 'blur(30px)',
        }}
      />

      {!hideChrome && <ProgressRail />}
      {!hideChrome && <OrderSummary />}

      <main
        className={clsx(
          'relative z-10',
          // rail lateral e bottom bar: só compensar espaço quando não é hero
          showRailPad && 'lg:pl-[124px]',
          showSummaryPad && 'xl:pr-[360px]',
          showRailPad && 'pt-[64px] lg:pt-0 pb-[88px] xl:pb-0',
        )}
      >
        {children}
      </main>
    </div>
  )
}
