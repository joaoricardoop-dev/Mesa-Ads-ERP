import clsx from 'clsx'
import { motion, AnimatePresence } from 'framer-motion'
import { useState } from 'react'
import { useCheckoutStore } from '../../state/checkoutStore'
import { productById, addOnById } from '../../data/products'
import { venueById } from '../../data/venues'
import { breakdownFor } from '../../lib/pricing'
import { brl, num } from '../../lib/format'
import { AnimatedNumber } from '../ui/AnimatedNumber'
import { Chip } from '../ui/Chip'

function useSnapshot() {
  const product = useCheckoutStore((s) => s.product)
  const venueIds = useCheckoutStore((s) => s.venueIds)
  const volume = useCheckoutStore((s) => s.volume)
  const weeks = useCheckoutStore((s) => s.weeks)
  const quantity = useCheckoutStore((s) => s.quantity)
  const addOnIds = useCheckoutStore((s) => s.addOnIds)
  const payment = useCheckoutStore((s) => s.payment)

  // compute derived values locally so we don't re-create them in the selector
  const reach = venueIds.reduce((acc, id) => {
    const v = venueById(id)
    return acc + (v?.clientesMes ?? 0)
  }, 0)
  const cycles = Math.max(1, Math.round(weeks / 4))
  const addOnsMonthly = addOnIds.reduce((sum, id) => {
    const ao = addOnById(id)
    return sum + (ao?.monthly ?? 0)
  }, 0)

  const method = payment ?? 'pix'
  const bd = breakdownFor({
    product,
    volume,
    weeks,
    quantity,
    addOnsMonthly,
    method,
  })

  return {
    product,
    venueIds,
    volume,
    weeks,
    quantity,
    addOnIds,
    payment,
    method,
    reach,
    cycles,
    addOnsMonthly,
    bd,
  }
}

export function OrderSummary() {
  const s = useSnapshot()
  const step = useCheckoutStore((st) => st.step)

  // Esconder no hero (ainda não tem produto) e na tela de sucesso
  if (step === 'hero' || step === 'success') return null

  return (
    <>
      <DesktopSummary snapshot={s} />
      <MobileSummary snapshot={s} />
    </>
  )
}

type Snap = ReturnType<typeof useSnapshot>

function DesktopSummary({ snapshot }: { snapshot: Snap }) {
  return (
    <aside
      className="fixed right-0 top-0 z-20 hidden h-screen w-[360px] flex-col border-l border-hairline bg-ink-900/60 backdrop-blur-xl xl:flex"
      aria-label="Resumo do pedido"
    >
      <div className="border-b border-hairline px-7 pt-8 pb-5">
        <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/40">Resumo</div>
        <div className="mt-1 font-display text-[22px] tracking-tight">
          {snapshot.product ? productById(snapshot.product)?.name : '—'}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-7 py-6 space-y-6 text-[13px]">
        <Block label="Alcance estimado">
          <AnimatedNumber value={snapshot.reach} className="font-mono text-[28px] text-chalk tabular" />
          <div className="text-chalk/50 mt-0.5">clientes/mês</div>
        </Block>

        <Block label="Locais" count={snapshot.venueIds.length}>
          <ul className="space-y-1.5 mt-1">
            <AnimatePresence initial={false}>
              {snapshot.venueIds.map((id) => {
                const v = venueById(id)
                if (!v) return null
                return (
                  <motion.li
                    key={id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ duration: 0.25 }}
                    className="flex justify-between gap-3"
                  >
                    <span className="text-chalk/80 line-clamp-1">{v.name}</span>
                    <span className="text-chalk/40 shrink-0 text-[11px]">{num(v.clientesMes)}/mês</span>
                  </motion.li>
                )
              })}
            </AnimatePresence>
            {snapshot.venueIds.length === 0 && (
              <li className="text-chalk/40">Nenhum local selecionado</li>
            )}
          </ul>
        </Block>

        {snapshot.product === 'coaster' && (
          <>
            <Block label="Volume / ciclo">
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-[22px] tabular">{num(snapshot.volume)}</span>
                <span className="text-chalk/50 text-[12px]">porta-copos</span>
              </div>
            </Block>

            <Block label="Duração">
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-[22px] tabular">{snapshot.weeks}</span>
                <span className="text-chalk/50 text-[12px]">semanas · {snapshot.cycles} ciclo(s)</span>
              </div>
            </Block>
          </>
        )}

        {(snapshot.product === 'vip-telas' || snapshot.product === 'vip-janela') && (
          <>
            <Block label="Quantidade">
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-[22px] tabular">{snapshot.quantity}</span>
                <span className="text-chalk/50 text-[12px]">
                  {snapshot.product === 'vip-telas' ? 'tela(s) 55"' : 'janela(s) digital'}
                </span>
              </div>
            </Block>

            <Block label="Duração">
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-[22px] tabular">{snapshot.weeks}</span>
                <span className="text-chalk/50 text-[12px]">semanas · {snapshot.cycles} ciclo(s)</span>
              </div>
            </Block>
          </>
        )}

        {snapshot.product === 'ativacao' && (
          <Block label="Formato">
            <div className="text-[13px] text-chalk/80 leading-snug">
              Live marketing · proposta sob consulta
            </div>
          </Block>
        )}

        {snapshot.addOnIds.length > 0 && (
          <Block label="Add-ons" count={snapshot.addOnIds.length}>
            <ul className="space-y-1.5 mt-1">
              {snapshot.addOnIds.map((id) => {
                const a = addOnById(id)
                if (!a) return null
                return (
                  <li key={id} className="flex justify-between gap-3">
                    <span className="text-chalk/80">{a.label}</span>
                    <span className="text-chalk/50 text-[11px]">
                      {a.monthly > 0 ? `${brl(a.monthly)}/mês` : 'sob consulta'}
                    </span>
                  </li>
                )
              })}
            </ul>
          </Block>
        )}

        <div className="pt-4 border-t border-hairline space-y-3">
          <Row label="Subtotal" value={brl(snapshot.bd.base)} muted />
          {snapshot.bd.paymentDiscount > 0 && (
            <Row label="Desconto Pix (-5%)" value={`- ${brl(snapshot.bd.paymentDiscount)}`} accent />
          )}
        </div>
      </div>

      <div className="border-t border-hairline px-7 py-6 bg-ink-950/50">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/40">Total</div>
            <div className="font-mono text-[28px] text-chalk tabular mt-1">
              <AnimatedNumber value={snapshot.bd.total} format={(v) => brl(v)} />
            </div>
          </div>
          <Chip tone={snapshot.method === 'pix' ? 'neon' : 'neutral'} size="xs" dot={snapshot.method === 'pix'}>
            {snapshot.bd.installments > 1
              ? `${snapshot.bd.installments}× ${brl(snapshot.bd.installmentValue)}`
              : 'à vista'}
          </Chip>
        </div>
        <p className="mt-3 text-[11px] text-chalk/40 leading-relaxed">
          Pagamento antes da veiculação. Relatório fotográfico semanal.
        </p>
      </div>
    </aside>
  )
}

function MobileSummary({ snapshot }: { snapshot: Snap }) {
  const [open, setOpen] = useState(false)

  return (
    <>
      {/* Bottom bar (always visible below rail) */}
      <div className="fixed bottom-0 inset-x-0 z-30 xl:hidden border-t border-hairline bg-ink-950/90 backdrop-blur-xl">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="flex items-center justify-between w-full px-5 py-3.5"
        >
          <div className="text-left">
            <div className="text-[10px] tracking-[0.2em] uppercase text-chalk/40">
              Resumo · {snapshot.venueIds.length} local(is)
            </div>
            <div className="font-mono text-[18px] tabular text-chalk mt-0.5">
              <AnimatedNumber value={snapshot.bd.total} format={(v) => brl(v)} />
            </div>
          </div>
          <span
            className={clsx(
              'size-8 rounded-full border border-hairline flex items-center justify-center transition-transform duration-300',
              open && 'rotate-180',
            )}
          >
            <svg viewBox="0 0 24 24" className="size-4 text-chalk/70" fill="none">
              <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </span>
        </button>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: 'auto' }}
              exit={{ height: 0 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden"
            >
              <div className="px-5 pb-5 pt-1 space-y-4 text-[13px] border-t border-hairline">
                <Row label="Alcance" value={`${num(snapshot.reach)}/mês`} />
                {snapshot.product === 'coaster' && (
                  <>
                    <Row label="Volume / ciclo" value={`${num(snapshot.volume)} porta-copos`} />
                    <Row label="Duração" value={`${snapshot.weeks} sem · ${snapshot.cycles} ciclos`} />
                  </>
                )}
                <Row label="Subtotal" value={brl(snapshot.bd.base)} muted />
                {snapshot.bd.paymentDiscount > 0 && (
                  <Row label="Pix -5%" value={`- ${brl(snapshot.bd.paymentDiscount)}`} accent />
                )}
                <Row label="Total" value={brl(snapshot.bd.total)} strong />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  )
}

function Block({
  label,
  children,
  count,
}: {
  label: string
  children: React.ReactNode
  count?: number
}) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <div className="text-[10px] tracking-[0.22em] uppercase text-chalk/40">{label}</div>
        {count !== undefined && (
          <span className="text-[11px] tabular font-mono text-chalk/60">{count}</span>
        )}
      </div>
      <div className="mt-2">{children}</div>
    </div>
  )
}

function Row({
  label,
  value,
  muted,
  accent,
  strong,
}: {
  label: string
  value: string
  muted?: boolean
  accent?: boolean
  strong?: boolean
}) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <span className="text-chalk/55 text-[12px] tracking-wide">{label}</span>
      <span
        className={clsx(
          'font-mono tabular text-[13px]',
          muted && 'text-chalk/60',
          accent && 'text-mesa-neon',
          strong && 'text-chalk text-[16px]',
        )}
      >
        {value}
      </span>
    </div>
  )
}
