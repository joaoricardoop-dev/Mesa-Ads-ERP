import clsx from 'clsx'
import { motion } from 'framer-motion'
import type { PaymentMethod } from '../../types'
import { PixIcon, BoletoIcon, CardIcon, CheckIcon } from '../../assets/logo'
import { Chip } from '../ui/Chip'
import { brl } from '../../lib/format'
import { springTight } from '../../lib/motion'

interface Props {
  value: PaymentMethod | null
  onChange: (v: PaymentMethod) => void
  baseAmount: number
  cycles: number
}

export function PaymentPicker({ value, onChange, baseAmount, cycles }: Props) {
  const pix = baseAmount * 0.95
  const boletoInstallment = baseAmount / Math.max(1, cycles)
  const cartaoInstallment = baseAmount / 3

  return (
    <div className="space-y-3">
      <PaymentCard
        selected={value === 'pix'}
        onSelect={() => onChange('pix')}
        icon={<PixIcon className="size-5" />}
        title="Pix à vista"
        sub={`${brl(pix)} · ${brl(baseAmount - pix)} de desconto`}
        badge={<Chip tone="neon" size="xs" dot>-5% à vista</Chip>}
        tone="neon"
      />
      <PaymentCard
        selected={value === 'boleto'}
        onSelect={() => onChange('boleto')}
        icon={<BoletoIcon className="size-5" />}
        title="Boleto parcelado"
        sub={
          cycles > 1
            ? `${cycles}× ${brl(boletoInstallment)} · 1 boleto por ciclo`
            : `${brl(baseAmount)} à vista (1 boleto)`
        }
        badge={<Chip tone="neutral" size="xs">sem juros</Chip>}
        tone="amber"
      />
      <PaymentCard
        selected={value === 'cartao'}
        onSelect={() => onChange('cartao')}
        icon={<CardIcon className="size-5" />}
        title="Cartão de crédito"
        sub={`até 3× ${brl(cartaoInstallment)} sem juros`}
        badge={<Chip tone="neutral" size="xs">3× sem juros</Chip>}
        tone="magenta"
      />
    </div>
  )
}

function PaymentCard({
  selected,
  onSelect,
  icon,
  title,
  sub,
  badge,
  tone,
}: {
  selected: boolean
  onSelect: () => void
  icon: React.ReactNode
  title: string
  sub: string
  badge: React.ReactNode
  tone: 'neon' | 'amber' | 'magenta'
}) {
  return (
    <motion.button
      whileHover={{ x: 2 }}
      whileTap={{ scale: 0.99 }}
      transition={springTight}
      onClick={onSelect}
      className={clsx(
        'group flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition-colors duration-300 ease-apple',
        'bg-gradient-to-br from-ink-800/60 to-ink-900/80',
        selected
          ? tone === 'neon'
            ? 'border-mesa-neon/60 shadow-neon-sm'
            : tone === 'amber'
              ? 'border-mesa-amber/50'
              : 'border-mesa-magenta/50'
          : 'border-hairline hover:border-hairlineBold',
      )}
    >
      <div
        className={clsx(
          'flex size-11 items-center justify-center rounded-xl border',
          tone === 'neon' && 'border-mesa-neon/30 bg-mesa-neon/10 text-mesa-neon',
          tone === 'amber' && 'border-mesa-amber/30 bg-mesa-amber/10 text-mesa-amber',
          tone === 'magenta' && 'border-mesa-magenta/30 bg-mesa-magenta/10 text-mesa-magenta',
        )}
      >
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <span className="font-display text-[16px] tracking-tight text-chalk">{title}</span>
          {badge}
        </div>
        <div className="mt-1 font-mono text-[12px] tabular text-chalk/60">{sub}</div>
      </div>
      <div
        className={clsx(
          'size-6 rounded-full border flex items-center justify-center transition-all duration-300',
          selected
            ? tone === 'neon'
              ? 'border-mesa-neon bg-mesa-neon text-ink-950'
              : tone === 'amber'
                ? 'border-mesa-amber bg-mesa-amber text-ink-950'
                : 'border-mesa-magenta bg-mesa-magenta text-ink-950'
            : 'border-chalk/20',
        )}
      >
        {selected && <CheckIcon className="size-3.5" />}
      </div>
    </motion.button>
  )
}
