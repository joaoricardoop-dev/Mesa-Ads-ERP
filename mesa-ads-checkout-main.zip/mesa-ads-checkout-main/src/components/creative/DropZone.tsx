import clsx from 'clsx'
import { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { UploadIcon } from '../../assets/logo'

interface Props {
  onFile: (url: string, name: string) => void
  currentName?: string | null
  currentUrl?: string | null
}

export function DropZone({ onFile, currentName, currentUrl }: Props) {
  const [over, setOver] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return
    const f = files[0]
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(f.type)) {
      setError('Formato inválido. Envie PNG, JPG ou WebP.')
      return
    }
    if (f.size > 10 * 1024 * 1024) {
      setError('Arquivo acima de 10MB. Reduza a resolução.')
      return
    }
    setError(null)
    const url = URL.createObjectURL(f)
    onFile(url, f.name)
  }

  return (
    <div>
      <motion.label
        htmlFor="art-upload"
        onDragOver={(e) => {
          e.preventDefault()
          setOver(true)
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setOver(false)
          handleFiles(e.dataTransfer.files)
        }}
        animate={{ scale: over ? 1.01 : 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className={clsx(
          'relative flex cursor-pointer flex-col items-center justify-center gap-4 rounded-3xl border-2 border-dashed py-14 px-6 text-center transition-colors duration-300 ease-apple',
          over
            ? 'border-mesa-neon bg-mesa-neon/5'
            : error
              ? 'border-rose-400/60 bg-rose-500/5'
              : 'border-hairlineBold bg-chalk/[0.02] hover:border-chalk/30 hover:bg-chalk/[0.04]',
        )}
      >
        <input
          ref={inputRef}
          id="art-upload"
          type="file"
          accept="image/png,image/jpeg,image/webp"
          className="sr-only"
          onChange={(e) => handleFiles(e.target.files)}
        />
        <motion.div
          animate={over ? { y: -6 } : { y: 0 }}
          className="flex size-16 items-center justify-center rounded-full border border-hairline bg-chalk/5"
        >
          <UploadIcon className="size-6 text-chalk/80" />
        </motion.div>
        <div>
          <div className="font-display text-[20px] tracking-tight">
            {over ? 'Solte para enviar' : currentName ? 'Substituir arte' : 'Arraste sua arte aqui'}
          </div>
          <div className="mt-1 text-[12px] text-chalk/55">
            PNG, JPG ou WebP · até 10MB · quadrado (1:1) recomendado
          </div>
        </div>
      </motion.label>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-3 text-[12px] text-rose-300"
            role="alert"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {currentName && (
        <div className="mt-4 flex items-center gap-3 rounded-2xl border border-hairline bg-ink-800/50 p-3">
          {currentUrl && (
            <img
              src={currentUrl}
              alt="preview"
              className="size-10 rounded-lg object-cover border border-hairline"
            />
          )}
          <div className="flex-1">
            <div className="text-[13px] text-chalk line-clamp-1">{currentName}</div>
            <div className="text-[11px] text-chalk/50">Enviado · pronto para veiculação</div>
          </div>
        </div>
      )}
    </div>
  )
}
