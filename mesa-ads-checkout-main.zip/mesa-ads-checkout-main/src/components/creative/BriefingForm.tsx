import { useCheckoutStore } from '../../state/checkoutStore'

const SUGGESTIONS = [
  'Nome da marca e setor',
  'Objetivo da campanha (awareness, conversão, lançamento)',
  'Paleta de cores e tom de voz',
  'CTA principal e QR code de destino',
  'Referências visuais de marcas que você admira',
]

export function BriefingForm() {
  const briefing = useCheckoutStore((s) => s.art.briefing)
  const setBriefing = useCheckoutStore((s) => s.setBriefing)

  return (
    <div>
      <label className="text-[10px] tracking-[0.22em] uppercase text-chalk/50">
        Briefing para o time de design
      </label>
      <textarea
        value={briefing}
        onChange={(e) => setBriefing(e.target.value)}
        placeholder="Conta o que sua marca faz, que tom você quer, cores principais, CTA principal, links e referências. O time Mesa.ads cuida do resto."
        className="mt-2 w-full min-h-[200px] rounded-2xl border border-hairline bg-ink-800/70 px-4 py-3 text-[14px] text-chalk/90 leading-relaxed placeholder:text-chalk/35 outline-none focus:border-mesa-neon/60 focus:shadow-[0_0_0_4px_rgba(0,230,64,0.1)] transition-all duration-200 ease-apple resize-y"
      />

      <div className="mt-5">
        <div className="text-[11px] tracking-[0.14em] uppercase text-chalk/40 mb-2">
          Sugestão de conteúdo
        </div>
        <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {SUGGESTIONS.map((s) => (
            <li
              key={s}
              className="flex items-start gap-2 text-[12px] text-chalk/55 leading-snug"
            >
              <span className="mt-[7px] size-1 rounded-full bg-mesa-neon/60 shrink-0" />
              {s}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-6 rounded-2xl border border-hairline bg-ink-800/40 p-4 text-[12px] text-chalk/55 leading-relaxed">
        <strong className="text-chalk/80">Prazo design:</strong> 5 dias úteis após faturamento.
        Depois da aprovação, produção leva 20 dias. O porta-copo vai para as mesas exatamente no
        início do próximo ciclo.
      </div>
    </div>
  )
}
