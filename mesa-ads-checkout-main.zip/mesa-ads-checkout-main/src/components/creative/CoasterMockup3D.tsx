import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { Environment, OrbitControls } from '@react-three/drei'
import { Suspense, useRef } from 'react'
import * as THREE from 'three'
import { Coaster3D } from '../hero/Coaster3D'

interface Props {
  imageUrl: string | null
  autoRotate?: boolean
  className?: string
}

const DEFAULT_VARIANT = {
  color: '#F5F5F3',
  ink: '#0A0A0C',
  label: ['sua', 'marca', 'aqui'],
  footer: 'mesa.ads',
  backColor: '#0A0A0C',
  backInk: '#F5F5F3',
  backLabel: 'mesa.ads',
}

function Model({ imageUrl, autoRotate }: { imageUrl: string | null; autoRotate: boolean }) {
  const group = useRef<THREE.Group>(null)
  const texture = imageUrl ? (useLoader(THREE.TextureLoader, imageUrl) as THREE.Texture) : null
  if (texture) {
    texture.colorSpace = THREE.SRGBColorSpace
    texture.anisotropy = 8
  }

  useFrame((state, delta) => {
    if (!group.current || !autoRotate) return
    group.current.rotation.z += delta * 0.35
    group.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.4) * 0.15
  })

  return (
    <group ref={group}>
      <Coaster3D
        variant={DEFAULT_VARIANT}
        artFront={texture}
        radius={1.25}
        thickness={0.08}
      />
    </group>
  )
}

export function CoasterMockup3D({ imageUrl, autoRotate = true, className }: Props) {
  return (
    <div className={className}>
      <Canvas
        dpr={[1, 2]}
        camera={{ position: [0, 0, 3.6], fov: 36 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[4, 6, 4]} intensity={1.2} />
          <directionalLight position={[-3, 2, -2]} intensity={0.4} color="#00E640" />
          <pointLight position={[0, 0, 4]} intensity={0.6} color="#FFFFFF" />
          <Environment preset="studio" />
          <Model imageUrl={imageUrl} autoRotate={autoRotate} />
          <OrbitControls enableZoom={false} enablePan={false} enableDamping dampingFactor={0.08} />
        </Suspense>
      </Canvas>
    </div>
  )
}
