import clsx from 'clsx'
import { useRef, useEffect } from 'react'

interface Props {
  min: number
  max: number
  step?: number
  value: number
  onChange: (v: number) => void
  label?: string
  className?: string
  /** optional marker points to emphasize (e.g., snap values) */
  ticks?: number[]
  format?: (v: number) => string
  accent?: 'neon' | 'magenta' | 'amber'
}

const accentMap = {
  neon: 'var(--c-neon)',
  magenta: 'var(--c-magenta)',
  amber: 'var(--c-amber)',
}

export function Slider({
  min,
  max,
  step = 1,
  value,
  onChange,
  label,
  className,
  ticks,
  format,
  accent = 'neon',
}: Props) {
  const ref = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!ref.current) return
    const pct = ((value - min) / (max - min)) * 100
    ref.current.style.setProperty('--pct', `${pct}%`)
    ref.current.style.setProperty('--accent', accentMap[accent])
  }, [value, min, max, accent])

  return (
    <div className={clsx('w-full', className)}>
      {label && (
        <div className="mb-2 flex items-center justify-between text-[12px] tracking-wide uppercase text-chalk/55">
          <span>{label}</span>
          <span className="font-mono text-chalk/80 tabular">{format ? format(value) : value}</span>
        </div>
      )}
      <div className="relative h-10 flex items-center">
        <input
          ref={ref}
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="mesa-slider w-full"
        />
        {ticks && (
          <div className="pointer-events-none absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-1">
            {ticks.map((t) => {
              const p = ((t - min) / (max - min)) * 100
              return (
                <span
                  key={t}
                  className="absolute size-1 rounded-full bg-chalk/20"
                  style={{ left: `calc(${p}% - 2px)` }}
                />
              )
            })}
          </div>
        )}
      </div>
      <style>{`
        .mesa-slider {
          -webkit-appearance: none;
          appearance: none;
          background: transparent;
          height: 40px;
        }
        .mesa-slider::-webkit-slider-runnable-track {
          height: 6px;
          border-radius: 999px;
          background: linear-gradient(to right, var(--accent) 0%, var(--accent) var(--pct), rgba(255,255,255,0.08) var(--pct), rgba(255,255,255,0.08) 100%);
        }
        .mesa-slider::-moz-range-track {
          height: 6px;
          border-radius: 999px;
          background: linear-gradient(to right, var(--accent) 0%, var(--accent) var(--pct), rgba(255,255,255,0.08) var(--pct), rgba(255,255,255,0.08) 100%);
        }
        .mesa-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 22px;
          height: 22px;
          border-radius: 999px;
          background: #fff;
          border: 0;
          margin-top: -8px;
          box-shadow: 0 0 0 3px rgba(0,0,0,0.4), 0 6px 16px -6px rgba(0,0,0,0.8), 0 0 22px -4px var(--accent);
          cursor: grab;
          transition: transform 120ms var(--ease-apple);
        }
        .mesa-slider::-webkit-slider-thumb:active { cursor: grabbing; transform: scale(1.06); }
        .mesa-slider::-moz-range-thumb {
          width: 22px;
          height: 22px;
          border-radius: 999px;
          background: #fff;
          border: 0;
          box-shadow: 0 0 0 3px rgba(0,0,0,0.4), 0 6px 16px -6px rgba(0,0,0,0.8), 0 0 22px -4px var(--accent);
          cursor: grab;
        }
      `}</style>
    </div>
  )
}
