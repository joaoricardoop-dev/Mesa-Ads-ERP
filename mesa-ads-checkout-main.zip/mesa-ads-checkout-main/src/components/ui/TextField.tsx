import clsx from 'clsx'
import { forwardRef, useId, useState } from 'react'

interface Props
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label: string
  error?: string
  hint?: string
  onValueChange?: (v: string) => void
}

export const TextField = forwardRef<HTMLInputElement, Props>(function TextField(
  { label, error, hint, className, value, onValueChange, onFocus, onBlur, onChange, ...rest },
  ref,
) {
  const id = useId()
  const [focused, setFocused] = useState(false)
  const hasValue = value !== undefined && value !== '' && value !== null

  const float = focused || hasValue

  return (
    <div className={clsx('group relative', className)}>
      <input
        id={id}
        ref={ref}
        value={value ?? ''}
        onChange={(e) => {
          onChange?.(e)
          onValueChange?.(e.target.value)
        }}
        onFocus={(e) => {
          setFocused(true)
          onFocus?.(e)
        }}
        onBlur={(e) => {
          setFocused(false)
          onBlur?.(e)
        }}
        aria-invalid={!!error}
        placeholder=" "
        className={clsx(
          'peer w-full h-14 rounded-2xl bg-ink-800/70 backdrop-blur-sm border px-4 pt-5 pb-1',
          'text-[15px] text-chalk caret-mesa-neon',
          'outline-none transition-[border,background,box-shadow] duration-200 ease-apple',
          error
            ? 'border-rose-400/60 focus:border-rose-400 focus:shadow-[0_0_0_4px_rgba(244,63,94,0.12)]'
            : 'border-hairline focus:border-mesa-neon/70 focus:shadow-[0_0_0_4px_rgba(0,230,64,0.10)] hover:border-hairlineBold',
        )}
        {...rest}
      />
      <label
        htmlFor={id}
        className={clsx(
          'pointer-events-none absolute left-4 transition-all duration-200 ease-apple',
          float
            ? 'top-1.5 text-[11px] tracking-[0.08em] uppercase text-chalk/55'
            : 'top-1/2 -translate-y-1/2 text-[15px] text-chalk/45',
          error && (float ? 'text-rose-300/90' : 'text-rose-300/70'),
        )}
      >
        {label}
      </label>
      {(error || hint) && (
        <div
          className={clsx(
            'mt-1.5 text-[11px] tracking-[0.02em] pl-1',
            error ? 'text-rose-300' : 'text-chalk/50',
          )}
          role={error ? 'alert' : undefined}
        >
          {error ?? hint}
        </div>
      )}
    </div>
  )
})
