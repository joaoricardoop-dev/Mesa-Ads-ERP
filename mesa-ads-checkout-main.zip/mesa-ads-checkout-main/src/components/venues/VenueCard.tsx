import clsx from 'clsx'
import { motion, AnimatePresence } from 'framer-motion'
import type { Venue } from '../../types'
import { Chip } from '../ui/Chip'
import { num } from '../../lib/format'
import { CheckIcon, StarIcon } from '../../assets/logo'
import { springTight } from '../../lib/motion'

interface Props {
  venue: Venue
  selected: boolean
  onToggle: () => void
}

export function VenueCard({ venue, selected, onToggle }: Props) {
  return (
    <motion.button
      type="button"
      onClick={onToggle}
      whileHover={{ y: -3 }}
      whileTap={{ scale: 0.985 }}
      transition={springTight}
      className={clsx(
        'group relative w-full overflow-hidden rounded-2xl border text-left transition-colors duration-300 ease-apple',
        'bg-gradient-to-br from-ink-800/60 to-ink-900/80 backdrop-blur-sm p-5',
        selected
          ? 'border-mesa-neon/60 shadow-neon-sm'
          : 'border-hairline hover:border-hairlineBold',
      )}
    >
      <AnimatePresence>
        {selected && (
          <motion.span
            initial={{ scale: 0, rotate: -30, opacity: 0 }}
            animate={{ scale: 1, rotate: 0, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={springTight}
            className="absolute top-4 right-4 flex size-7 items-center justify-center rounded-full bg-mesa-neon text-ink-950 shadow-neon-sm"
          >
            <CheckIcon className="size-4" />
          </motion.span>
        )}
      </AnimatePresence>

      <div className="flex flex-wrap items-start gap-2 pr-10">
        {venue.classes.map((c) => (
          <Chip key={c} tone="neutral" size="xs">
            {c}
          </Chip>
        ))}
        {venue.tag && (
          <Chip tone={venue.tag === 'Premium' ? 'magenta' : 'ice'} size="xs">
            {venue.tag}
          </Chip>
        )}
      </div>

      <h3 className="mt-3 font-display text-[18px] leading-tight tracking-tight text-chalk text-pretty">
        {venue.name}
      </h3>
      <div className="mt-1 text-[12px] text-chalk/50">{venue.neighborhood}</div>

      {/* metrics */}
      <dl className="mt-5 grid grid-cols-2 gap-3 text-[11px]">
        <Metric k="Mesas" v={num(venue.mesas)} />
        <Metric k="Assentos" v={num(venue.assentos)} />
        <Metric k="Clientes/mês" v={num(venue.clientesMes)} accent />
        <Metric k="Cap. porta-copos" v={num(venue.capCoasters)} />
      </dl>

      <footer className="mt-5 flex items-center justify-between border-t border-hairline pt-3">
        <div className="flex items-center gap-1 text-chalk/60">
          {Array.from({ length: 5 }).map((_, i) => (
            <StarIcon
              key={i}
              filled={i < Math.round(venue.rating)}
              className={clsx(
                'size-3',
                i < Math.round(venue.rating) ? 'text-mesa-amber' : 'text-chalk/20',
              )}
            />
          ))}
          <span className="ml-1 font-mono text-[11px] tabular">
            {venue.rating ? venue.rating.toFixed(2) : '—'}
          </span>
        </div>
        <div className="text-[11px] text-chalk/40">{venue.manager.split(' ')[0]}</div>
      </footer>
    </motion.button>
  )
}

function Metric({ k, v, accent }: { k: string; v: string; accent?: boolean }) {
  return (
    <div>
      <dt className="text-[10px] tracking-[0.18em] uppercase text-chalk/40">{k}</dt>
      <dd
        className={clsx(
          'mt-0.5 font-mono text-[13px] tabular',
          accent ? 'text-mesa-neon' : 'text-chalk/85',
        )}
      >
        {v}
      </dd>
    </div>
  )
}
