import { AnimatePresence } from 'framer-motion'
import { useEffect } from 'react'
import { useCheckoutStore, stepsForProduct } from './state/checkoutStore'
import { AppShell } from './components/layout/AppShell'
import { WhatsAppFloat } from './components/ui/WhatsAppFloat'
import { StepHero } from './components/steps/StepHero'
import { StepVenues } from './components/steps/StepVenues'
import { StepVolume } from './components/steps/StepVolume'
import { StepDuration } from './components/steps/StepDuration'
import { StepUpsell } from './components/steps/StepUpsell'
import { StepCreative } from './components/steps/StepCreative'
import { StepCheckout as StepCheckoutForm } from './components/steps/StepCheckout'
import { StepSuccess } from './components/steps/StepSuccess'

export default function App() {
  const step = useCheckoutStore((s) => s.step)
  const product = useCheckoutStore((s) => s.product)
  const goTo = useCheckoutStore((s) => s.goTo)

  useEffect(() => {
    const allowed = stepsForProduct(product)
    if (!allowed.includes(step)) {
      const fallbackIdx = allowed.indexOf('hero')
      const next = allowed[fallbackIdx + 1] ?? 'hero'
      goTo(next)
    }
  }, [step, product, goTo])

  return (
    <AppShell>
      <AnimatePresence mode="wait">
        {step === 'hero' && <StepHero key="hero" />}
        {step === 'venues' && <StepVenues key="venues" />}
        {step === 'volume' && <StepVolume key="volume" />}
        {step === 'duration' && <StepDuration key="duration" />}
        {step === 'upsell' && <StepUpsell key="upsell" />}
        {step === 'creative' && <StepCreative key="creative" />}
        {step === 'checkout' && <StepCheckoutForm key="checkout" />}
        {step === 'success' && <StepSuccess key="success" />}
      </AnimatePresence>

      {/* Escondido no success; afasta do bottom-sheet mobile (~96px) */}
      {step !== 'success' && (
        <WhatsAppFloat
          message="Olá! Estou montando uma campanha no checkout e preciso de ajuda."
          showAfterMs={1600}
          showTooltip={false}
          className="bottom-[108px] xl:bottom-8"
        />
      )}
    </AppShell>
  )
}
